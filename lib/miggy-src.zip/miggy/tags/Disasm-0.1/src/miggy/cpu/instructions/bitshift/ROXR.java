package miggy.cpu.instructions.bitshift;

import miggy.cpu.DataSize;
import miggy.cpu.DecodedInstruction;
import miggy.cpu.operands.OperandFactory;

// $Revision: 2 $
public class ROXR
{
	public final DecodedInstruction decode(int address, int opcode, DataSize size)
	{
		DecodedInstruction di = new DecodedInstruction("roxr" + size.ext(), opcode, address, size);

		if((opcode & 0x0020) == 0)
		{
			//immediate data with shift count
			int shift = (opcode & 0x0e00) >> 9;
			if(shift == 0)
				shift = 8;

			di.setSrc(OperandFactory.literal(shift));
			di.setDst(OperandFactory.dataReg(opcode & 0x0007));
		}
		else
		{
			//Dn/Dn
			di.setSrc(OperandFactory.dataReg((opcode & 0x0e00) >> 9));
			di.setDst(OperandFactory.dataReg(opcode & 0x007));
		}

		return di;
	}
}
