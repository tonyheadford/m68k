package miggy.cpu;

import miggy.cpu.operands.Operand;
import miggy.cpu.operands.OperandFactory;
import miggy.utils.TextUtil;

/*
//  Miggy - Java Amiga Emulator
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 2 $
*/
public class DecodedInstruction
{
	private final String name;
	private final int opcode;
	private final int address;
	private final DataSize opsize;
	private Operand src = OperandFactory.UnusedOperand();
	private Operand dst = OperandFactory.UnusedOperand();
	private int data = 0;
	private boolean usesData = false;

	public DecodedInstruction(String name, int opcode, int address, DataSize opsize)
	{
		this.name = name;
		this.opcode = opcode;
		this.address = address;
		this.opsize = opsize;
	}

	public String name() { return name; }
	public int opcode() { return opcode; }
	public int address() { return address; }
	public DataSize opsize() { return opsize; }
	public Operand src() { return src; }
	public void setSrc(Operand src)
	{
		this.src = src;
	}
	public Operand dst() { return dst; }
	public void setDst(Operand dst)
	{
		this.dst = dst;
	}
	public void setData(int data)
	{
		this.data = data;
		usesData = true;
	}
	public int getData() { return data; }

	public boolean usesData() { return usesData; }

	@Override public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append(TextUtil.toHex(address));
		sb.append("  ");
		sb.append(TextUtil.toHex((short)opcode));

		int bytes = src.offset() + dst.offset();
		int count = 0;
		for(int n = 0; n < bytes; n+=2)
		{
			sb.append(" ");
			sb.append(TextUtil.toHex(Sys.MEM.peekWord(address + 2 + n)));
			count++;
		}

		for(; count < 4; count++)
		{
			sb.append("     ");
		}

		sb.append("  ");

		sb.append(TextUtil.pad(name, 9));

		if(src != OperandFactory.UnusedOperand())
		{
			sb.append(src);
		}
		if(dst != OperandFactory.UnusedOperand())
		{
			//requires that single param instructions use src not dst
			sb.append(",");
			sb.append(dst);
		}
		return sb.toString();
	}
}
