package miggy.memory;

import miggy.cpu.DataSize;

import java.nio.ByteBuffer;

/*
//  Miggy - Java Amiga Emulator
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 2 $
*/
public class TestMem implements MemoryController
{
	private ByteBuffer buf;

	private TestMem()
	{}

	public static TestMem create(int size)
	{
		TestMem tm = new TestMem();
		tm.buf = ByteBuffer.allocate(size);

		return tm;
	}

	public byte peekByte(int address)
	{
		return buf.get(address);
	}

	public short peekWord(int address)
	{
		return buf.getShort(address);
	}

	public int peekLong(int address)
	{
		return buf.getInt(address);
	}

	public void pokeByte(int address, byte value)
	{
		buf.put(address, value);
	}

	public void pokeWord(int address, short value)
	{
		buf.putShort(address, value);
	}

	public void pokeLong(int address, int value)
	{
		buf.putInt(address, value);
	}

	public int peek(int address, DataSize size)
	{
		switch(size)
		{
			case Byte:
				return buf.get(address);
			case Word:
				return buf.getShort(address);
			case Long:
				return buf.getInt(address);
		}
		throw new IllegalArgumentException("Invalid data size specified");
	}

	public void poke(int address, int value, DataSize size)
	{
		switch(size)
		{
			case Byte:
				buf.put(address, (byte)value);
			case Word:
				buf.putShort(address, (short)value);
			case Long:
				buf.putInt(address, value);
		}
	}
}
