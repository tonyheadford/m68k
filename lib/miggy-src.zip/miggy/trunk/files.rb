#!/usr/bin/env ruby -w
# Build a list for the classes for the CPU ops.  This needs a bit of pruning by hand afterwards :(
# $Revision: 2 $
require 'find'
base = "d:/amiga/miggy/src/src/miggy/cpu/ops"
$excludes = [".svn", ".", ".."]
$files = []

def listme(dir)
	Find.find(dir) do |path|
		if FileTest.directory?(path)
			if $excludes.include?(File.basename(path))
				Find.prune
			end
			next
		else
			$files << path.gsub(/d:\/amiga\/miggy\/src\/src\//, '').gsub(/\//,'.').gsub(/\.java$/, '')
		end
	end
end

listme(base)
$files.sort.each { |f| puts f }
