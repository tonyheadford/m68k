package miggy.display;

import miggy.api.display.DisplayController;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.*;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public class Display
{
	private DisplayController controller;
	private Frame frame = null;
	private BufferedImage bufferedImage = null;
	private VolatileImage volatileImage = null;
	private int[] vram = null;
	private int[] indexBuffer = null;

	private String title;
	private int width;
	private int height;

	public Display(DisplayController dc, String title)
	{
		this.controller = dc;
		this.title = title;

		frame = new Frame(title) {
			public void paint(Graphics g) {
				stretchBlit(g);
			}
		};

		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e)
			{
				controller.displayClosing();
				frame.dispose();
			}
		});
	}

	public void initDisplay(int width, int height)
	{
		this.width = width;
		this.height = height;

		DirectColorModel model = new DirectColorModel(24, 0x00ff0000, 0x0000ff00, 0x000000ff);
		WritableRaster raster = model.createCompatibleWritableRaster(width, height);
		DataBufferInt db = (DataBufferInt) raster.getDataBuffer();
		vram = db.getData();

		bufferedImage = new BufferedImage(model, raster, true, null);
		expandFrame();
		frame.setVisible(true);
		frame.setResizable(false);

		volatileImage = frame.createVolatileImage(width, height);
//		frame.addKeyListener(this);
//		frame.addWindowListener(new Closer());
	}

	public void resize(int width, int height)
	{
		this.width = width;
		this.height = height;
		expandFrame();
	}

	public void close()
	{
		frame.dispose();
	}

	protected void expandFrame()
	{
		frame.setSize(new Dimension(width + frame.getInsets().left + frame.getInsets().right, height + frame.getInsets().top + frame.getInsets().bottom));
	}


	protected synchronized void stretchBlit(Graphics g)
	{
		int l = frame.getInsets().left;
		int t = frame.getInsets().top;

//		if (antiAlias) ((Graphics2D)g).setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
		g.drawImage(bufferedImage, l, t, null);
	}
}
