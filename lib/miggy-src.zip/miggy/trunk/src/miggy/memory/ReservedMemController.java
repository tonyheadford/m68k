package miggy.memory;

import miggy.api.cpu.Size;
import miggy.api.memory.AddressSpace;
import miggy.api.config.MachineDefinition;
import miggy.api.config.ConfigurationException;

import java.util.logging.Logger;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public final class ReservedMemController implements AddressSpace
{
	private static Logger logger = Logger.getLogger(ReservedMemController.class.getName());
	private static int[] noise = {0xfafff5ff, 0x7f57feff}; //lots of ones and a few zeroes
	private static int noiseIdx = 0;

	public ReservedMemController()
	{
		logger.info("Creating ReservedMemController");
	}
	
	/**
	 * Initialise the controller
	 *
	 * @param config Configuration object containing machine settings
	 * @throws miggy.api.config.ConfigurationException
	 *          if Configuration holds invalid information for this component
	 */
	public void init(MachineDefinition config) throws ConfigurationException
	{
	}

	public final void reset()
	{
		logger.info("Reseting Reserved Memory");
//		dummyValue = 0xff00ff00;
	}

	public final int peek(int address, Size size)
	{
//		logger.info("RESERVED READ: " + TextUtil.toHex(address) + " (" + size + ")");
		return makeNoise() & size.mask();
/*
		if(size == Size.Byte)
		{
			dummyValue = ~(dummyValue);
			return dummyValue & size.mask();
		}
		else
		{
			return 0x61006100 & size.mask();
		}
*/
	}

	public final void poke(int address, int value, Size size)
	{
//		logger.info("RESERVED WRITE: " + TextUtil.toHex(address) + ": " + TextUtil.toHex(value) + " (" + size + ")");
	}

	public final int directPeek(int address, Size size)
	{
//		dummyValue = ~(dummyValue);
//		return dummyValue & size.mask();
		return makeNoise() & size.mask();
	}

	public final void directPoke(int address, int value, Size size)
	{
	}

	private int makeNoise()
	{
		int val = noise[noiseIdx];
		noiseIdx ^= 1;
		return val;
	}
}
