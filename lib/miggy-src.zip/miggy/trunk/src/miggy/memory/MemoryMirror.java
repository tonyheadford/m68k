package miggy.memory;

import miggy.api.config.ConfigurationException;
import miggy.api.config.MachineDefinition;
import miggy.api.cpu.Size;
import miggy.api.memory.MappedSpace;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public class MemoryMirror implements MappedSpace
{
	private final MappedSpace mirror;
	private final int baseAddress;

	public MemoryMirror(int baseAddress, MappedSpace mirror)
	{
		this.baseAddress = baseAddress;
		this.mirror = mirror;
	}

	/**
	 * Initialise the controller
	 *
	 * @param config Configuration object containing machine settings
	 * @throws miggy.api.config.ConfigurationException
	 *          if Configuration holds invalid information for this component
	 */
	public void init(MachineDefinition config) throws ConfigurationException
	{
	}

	/**
	 * Reset the memory to it's power-on state
	 */
	public void reset()
	{
	}

	public int getBaseAddress()
	{
		return baseAddress;
	}

	public int getSize()
	{
		return mirror.getSize();
	}

	/**
	 * Read a value from the specified address. The size of the data read is specified with the
	 * size parameter.
	 *
	 * @param address A 24-bit memory address
	 * @param size	DataSize value representing the size of the read.
	 * @return The value read from the address
	 */
	public int peek(int address, Size size)
	{
		address = (address - baseAddress) + mirror.getBaseAddress();
		return mirror.peek(address, size);
	}

	/**
	 * Write a value into the specified address.  The size of the write is specified with the size
	 * parameter.
	 *
	 * @param address A 24-bit memory address
	 * @param value   The value to be written. Value will be truncated to the specified size.
	 * @param size	DataSize value representing the size of the read.
	 */
	public void poke(int address, int value, Size size)
	{
		address = (address - baseAddress) + mirror.getBaseAddress();
		mirror.poke(address, value, size);
	}

	/**
	 * Read a value from the specified address without causing any side effects
	 * such as may happen when reading from custom chip registers. Used by the debugger.
	 * The size of the data read is specified with the size parameter.
	 *
	 * @param address A 24-bit memory address
	 * @param size	DataSize value representing the size of the read.
	 * @return The value read from the address
	 */
	public int directPeek(int address, Size size)
	{
		address = (address - baseAddress) + mirror.getBaseAddress();
		return mirror.directPeek(address, size);
	}

	/**
	 * Write a value into the specified address without causing any side effects
	 * such as may happen when reading from custom chip registers. Used by the debugger.
	 * The size of the write is specified with the size parameter.
	 *
	 * @param address A 24-bit memory address
	 * @param value   The value to be written. Value will be truncated to the specified size.
	 * @param size	DataSize value representing the size of the read.
	 */
	public void directPoke(int address, int value, Size size)
	{
		address = (address - baseAddress) + mirror.getBaseAddress();
		mirror.directPoke(address, value, size);
	}
}
