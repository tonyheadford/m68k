package miggy.memory;

import miggy.api.config.ConfigurationException;
import miggy.api.config.MachineDefinition;
import miggy.api.cpu.Size;
import miggy.api.memory.MappedSpace;

import java.nio.ByteBuffer;
import java.util.logging.Logger;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public final class SlowMemController implements MappedSpace
{
	private static Logger logger = Logger.getLogger("Miggy.Memory.SlowMem");
	private ByteBuffer buffer;
	private int baseAddress;
	private int size;

	public SlowMemController(int baseAddress)
	{
		this.baseAddress = baseAddress;
	}

	public final void init(MachineDefinition config) throws ConfigurationException
	{
		size = config.getSlowRamSize();

		if(size != 512)
		{
			logger.severe("Fast Memory specified (" + size + ") is not 0 or 512");
			throw new ConfigurationException("Invalid slow ram size: " + size);
		}

		buffer = ByteBuffer.allocateDirect(size * 1024);
	}

	public final void reset()
	{
		logger.info("Resetting Slow RAM Controller");
	}

	public final int getBaseAddress()
	{
		return baseAddress;
	}

	public final int getSize()
	{
		return size;
	}
	
	public int peek(int address, Size size)
	{
		return directPeek(address, size);
	}

	public void poke(int address, int value, Size size)
	{
		directPoke(address, value, size);
	}

	public int directPeek(int address, Size size)
	{
		int val;
		address -= baseAddress;
		switch(size)
		{
			case Byte:
			{
				val = buffer.get(address);
				break;
			}
			case Word:
			{
				val = buffer.getShort(address);
				break;
			}
			case Long:
			{
				val = buffer.getInt(address);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
		return val & size.mask();
	}

	public void directPoke(int address, int value, Size size)
	{
		address -= baseAddress;
		switch(size)
		{
			case Byte:
			{
				buffer.put(address, (byte)value);
				break;
			}
			case Word:
			{
				buffer.putShort(address, (short)value);
				break;
			}
			case Long:
			{
				buffer.putInt(address, value);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
	}
}
