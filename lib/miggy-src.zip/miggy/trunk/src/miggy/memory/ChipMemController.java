package miggy.memory;

import miggy.api.config.ConfigurationException;
import miggy.api.config.MachineDefinition;
import miggy.api.cpu.Size;
import miggy.api.memory.MappedSpace;

import java.nio.ByteBuffer;
import java.util.logging.Logger;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public final class ChipMemController implements MappedSpace
{
	private static Logger logger = Logger.getLogger("Miggy.Memory.ChipRam");
	protected ByteBuffer buffer;
	private int size;

	public ChipMemController()
	{
	}

	/**
	 * Initialise the controller
	 *
	 * @param config Configuration object containing machine settings
	 * @throws miggy.api.config.ConfigurationException
	 *          if Configuration holds invalid information for this component
	 */
	public void init(MachineDefinition config) throws ConfigurationException
	{
		size = config.getChipRamSize();

		//chipmem must be 512 or 1024 (A1000 was 256, later Amis were 2048)
		if(size != 512 && size != 1024)
		{
			logger.severe("Chip Memory specified (" + size + ") is not 512 or 1024");
			throw new ConfigurationException("Invalid chip ram size: " + size);
		}

		buffer = ByteBuffer.allocateDirect(size * 1024);
		logger.config("Allocated " + buffer.capacity() + " bytes of chip ram");
	}

	public final void reset()
	{
		logger.info("Reset CHIP ram");
	}

	public int getSize()
	{
		return size;
	}

	public int getBaseAddress()
	{
		return 0;
	}

	/**
	 * Read a value from the specified address. The size of the data read is specified with the
	 * size parameter.
	 *
	 * @param address A memory address masked to this address space
	 * @param size	DataSize value representing the size of the read.
	 * @return The value read from the address
	 */
	public int peek(int address, Size size)
	{
		int val;

		switch(size)
		{
			case Byte:
			{
				val = buffer.get(address);
				break;
			}
			case Word:
			{
				val = buffer.getShort(address);
				break;
			}
			case Long:
			{
				val = buffer.getInt(address);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
		return val & size.mask();
	}

	/**
	 * Write a value into the specified address.  The size of the write is specified with the size
	 * parameter.
	 *
	 * @param address A memory address masked to this address space
	 * @param value   The value to be written. Value will be truncated to the specified size.
	 * @param size	DataSize value representing the size of the read.
	 */
	public void poke(int address, int value, Size size)
	{
		switch(size)
		{
			case Byte:
			{
				buffer.put(address, (byte)value);
				break;
			}
			case Word:
			{
				buffer.putShort(address, (short)value);
				break;
			}
			case Long:
			{
				buffer.putInt(address, value);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
	}

	/**
	 * Read a value from the specified address without causing any side effects
	 * such as may happen when reading from custom chip registers. Used by the debugger.
	 * The size of the data read is specified with the size parameter.
	 *
	 * @param address A memory address masked to this address space
	 * @param size	DataSize value representing the size of the read.
	 * @return The value read from the address
	 */
	public int directPeek(int address, Size size)
	{
		int val;

		switch(size)
		{
			case Byte:
			{
				val = buffer.get(address);
				break;
			}
			case Word:
			{
				val = buffer.getShort(address);
				break;
			}
			case Long:
			{
				val = buffer.getInt(address);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
		return val & size.mask();
	}

	/**
	 * Write a value into the specified address without causing any side effects
	 * such as may happen when reading from custom chip registers. Used by the debugger.
	 * The size of the write is specified with the size parameter.
	 *
	 * @param address A memory address masked to this address space
	 * @param value   The value to be written. Value will be truncated to the specified size.
	 * @param size	DataSize value representing the size of the read.
	 */
	public void directPoke(int address, int value, Size size)
	{
		switch(size)
		{
			case Byte:
			{
				buffer.put(address, (byte)value);
				break;
			}
			case Word:
			{
				buffer.putShort(address, (short)value);
				break;
			}
			case Long:
			{
				buffer.putInt(address, value);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
	}
}
