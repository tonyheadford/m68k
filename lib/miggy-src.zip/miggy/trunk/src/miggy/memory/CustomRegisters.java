package miggy.memory;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

/**
 * References taken from release 40.15 of includes / version 39.1 custom.i
 * Custom chip register offsets
 */
public class CustomRegisters
{
	public static final int CUSTOM_BASE	=	0x00dff000;
	public static final int BLTDDAT		=	CUSTOM_BASE + 0x000;
	public static final int DMACONR		=	CUSTOM_BASE + 0x002;
	public static final int VPOSR		=	CUSTOM_BASE + 0x004;
	public static final int VHPOSR		=	CUSTOM_BASE + 0x006;
	public static final int DSKDATR		=	CUSTOM_BASE + 0x008;
	public static final int JOY0DAT		=	CUSTOM_BASE + 0x00A;
	public static final int JOY1DAT		=	CUSTOM_BASE + 0x00C;
	public static final int CLXDAT		=	CUSTOM_BASE + 0x00E;

	public static final int ADKCONR		=	CUSTOM_BASE + 0x010;
	public static final int POT0DAT		=	CUSTOM_BASE + 0x012;
	public static final int POT1DAT		=	CUSTOM_BASE + 0x014;
	public static final int POTINP		=	CUSTOM_BASE + 0x016;
	public static final int SERDATR		=	CUSTOM_BASE + 0x018;
	public static final int DSKBYTR		=	CUSTOM_BASE + 0x01A;
	public static final int INTENAR		=	CUSTOM_BASE + 0x01C;
	public static final int INTREQR		=	CUSTOM_BASE + 0x01E;

	public static final int DSKPTH		=	CUSTOM_BASE + 0x020;
	public static final int DSKPTL		=	CUSTOM_BASE + 0x022;
	public static final int DSKLEN		=	CUSTOM_BASE + 0x024;
	public static final int DSKDAT		=	CUSTOM_BASE + 0x026;
	public static final int REFPTR		=	CUSTOM_BASE + 0x028;
	public static final int VPOSW		=	CUSTOM_BASE + 0x02A;
	public static final int VHPOSW		=	CUSTOM_BASE + 0x02C;
	public static final int COPCON		=	CUSTOM_BASE + 0x02E;
	public static final int SERDAT		=	CUSTOM_BASE + 0x030;
	public static final int SERPER		=	CUSTOM_BASE + 0x032;
	public static final int POTGO		=	CUSTOM_BASE + 0x034;
	public static final int JOYTEST		=	CUSTOM_BASE + 0x036;
	public static final int STREQU		=	CUSTOM_BASE + 0x038;
	public static final int STRVBL		=	CUSTOM_BASE + 0x03A;
	public static final int STRHOR		=	CUSTOM_BASE + 0x03C;
	public static final int STRLONG		=	CUSTOM_BASE + 0x03E;

	public static final int BLTCON0		=	CUSTOM_BASE + 0x040;
	public static final int BLTCON1		=	CUSTOM_BASE + 0x042;
	public static final int BLTAFWM		=	CUSTOM_BASE + 0x044;
	public static final int BLTALWM		=	CUSTOM_BASE + 0x046;
	public static final int BLTCPTH		=	CUSTOM_BASE + 0x048;
	public static final int BLTCPTL		=	CUSTOM_BASE + 0x04a;
	public static final int BLTBPTH		=	CUSTOM_BASE + 0x04C;
	public static final int BLTBPTL		=	CUSTOM_BASE + 0x04e;
	public static final int BLTAPTH		=	CUSTOM_BASE + 0x050;
	public static final int BLTAPTL		=	CUSTOM_BASE + 0x052;
	public static final int BLTDPTH		=	CUSTOM_BASE + 0x054;
	public static final int BLTDPTL		=	CUSTOM_BASE + 0x056;
	public static final int BLTSIZE		=	CUSTOM_BASE + 0x058;
	public static final int BLTCON0L	=	CUSTOM_BASE + 0x05B;		// note: byte access only
	public static final int BLTSIZV		=	CUSTOM_BASE + 0x05C;
	public static final int BLTSIZH		=	CUSTOM_BASE + 0x05E;

	public static final int BLTCMOD		=	CUSTOM_BASE + 0x060;
	public static final int BLTBMOD		=	CUSTOM_BASE + 0x062;
	public static final int BLTAMOD		=	CUSTOM_BASE + 0x064;
	public static final int BLTDMOD		=	CUSTOM_BASE + 0x066;

	public static final int BLTCDAT		=	CUSTOM_BASE + 0x070;
	public static final int BLTBDAT		=	CUSTOM_BASE + 0x072;
	public static final int BLTADAT		=	CUSTOM_BASE + 0x074;

	public static final int SPRHDAT		=	CUSTOM_BASE + 0x078;

	public static final int DENISEID	=	CUSTOM_BASE + 0x07C;
	public static final int DSKSYNC		=	CUSTOM_BASE + 0x07E;

	public static final int COP1LCH		=	CUSTOM_BASE + 0x080;
	public static final int COP1LCL		=	CUSTOM_BASE + 0x082;
	public static final int COP2LCH		=	CUSTOM_BASE + 0x084;
	public static final int COP2LCL		=	CUSTOM_BASE + 0x086;
	public static final int COPJMP1		=	CUSTOM_BASE + 0x088;
	public static final int COPJMP2		=	CUSTOM_BASE + 0x08A;
	public static final int COPINS		=	CUSTOM_BASE + 0x08C;
	public static final int DIWSTRT		=	CUSTOM_BASE + 0x08E;
	public static final int DIWSTOP		=	CUSTOM_BASE + 0x090;
	public static final int DDFSTRT		=	CUSTOM_BASE + 0x092;
	public static final int DDFSTOP		=	CUSTOM_BASE + 0x094;
	public static final int DMACON		=	CUSTOM_BASE + 0x096;
	public static final int CLXCON		=	CUSTOM_BASE + 0x098;
	public static final int INTENA		=	CUSTOM_BASE + 0x09A;
	public static final int INTREQ		=	CUSTOM_BASE + 0x09C;
	public static final int ADKCON		=	CUSTOM_BASE + 0x09E;

	public static final int AUD			=	CUSTOM_BASE + 0x0A0;
	public static final int AUD0LCH		=	CUSTOM_BASE + 0x0A0;
	public static final int AUD0LCL		=	CUSTOM_BASE + 0x0A2;
	public static final int AUD0LEN		=	CUSTOM_BASE + 0x0A4;
	public static final int AUD0PER		=	CUSTOM_BASE + 0x0A6;
	public static final int AUD0VOL		=	CUSTOM_BASE + 0x0A8;
	public static final int AUD0DAT		=	CUSTOM_BASE + 0x0AA;

	public static final int AUD1		=	CUSTOM_BASE + 0x0B0;
	public static final int AUD1LCH		=	CUSTOM_BASE + 0x0B0;
	public static final int AUD1LCL		=	CUSTOM_BASE + 0x0B2;
	public static final int AUD1LEN		=	CUSTOM_BASE + 0x0B4;
	public static final int AUD1PER		=	CUSTOM_BASE + 0x0B6;
	public static final int AUD1VOL		=	CUSTOM_BASE + 0x0B8;
	public static final int AUD1DAT		=	CUSTOM_BASE + 0x0BA;

	public static final int AUD2		=	CUSTOM_BASE + 0x0C0;
	public static final int AUD2LCH		=	CUSTOM_BASE + 0x0C0;
	public static final int AUD2LCL		=	CUSTOM_BASE + 0x0C2;
	public static final int AUD2LEN		=	CUSTOM_BASE + 0x0C4;
	public static final int AUD2PER		=	CUSTOM_BASE + 0x0C6;
	public static final int AUD2VOL		=	CUSTOM_BASE + 0x0C8;
	public static final int AUD2DAT		=	CUSTOM_BASE + 0x0CA;

	public static final int AUD3		=	CUSTOM_BASE + 0x0D0;
	public static final int AUD3LCH		=	CUSTOM_BASE + 0x0D0;
	public static final int AUD3LCL		=	CUSTOM_BASE + 0x0D2;
	public static final int AUD3LEN		=	CUSTOM_BASE + 0x0D4;
	public static final int AUD3PER		=	CUSTOM_BASE + 0x0D6;
	public static final int AUD3VOL		=	CUSTOM_BASE + 0x0D8;
	public static final int AUD3DAT		=	CUSTOM_BASE + 0x0DA;

	// AudChannel
	public static final int AC_PTR		=	0x00;	// ptr to start of waveform data
	public static final int AC_LEN		=	0x04;	// length of waveform in words
	public static final int AC_PER		=	0x06;	// sample period
	public static final int AC_VOL		=	0x08;	// volume
	public static final int AC_DAT		=	0x0A;	// sample pair
	public static final int AC_SIZEOF	=	0x10;

	public static final int BPL1PTH		=	CUSTOM_BASE + 0x0E0;
	public static final int BPL1PTL		=	CUSTOM_BASE + 0x0E2;
	public static final int BPL2PTH		=	CUSTOM_BASE + 0x0E4;
	public static final int BPL2PTL		=	CUSTOM_BASE + 0x0E6;
	public static final int BPL3PTH		=	CUSTOM_BASE + 0x0E8;
	public static final int BPL3PTL		=	CUSTOM_BASE + 0x0EA;
	public static final int BPL4PTH		=	CUSTOM_BASE + 0x0EC;
	public static final int BPL4PTL		=	CUSTOM_BASE + 0x0EE;
	public static final int BPL5PTH		=	CUSTOM_BASE + 0x0F0;
	public static final int BPL5PTL		=	CUSTOM_BASE + 0x0F2;
	public static final int BPL6PTH		=	CUSTOM_BASE + 0x0F4;
	public static final int BPL6PTL		=	CUSTOM_BASE + 0x0F6;

	public static final int BPLCON0		=	CUSTOM_BASE + 0x100;
	public static final int BPLCON1		=	CUSTOM_BASE + 0x102;
	public static final int BPLCON2		=	CUSTOM_BASE + 0x104;
	public static final int BPLCON3		=	CUSTOM_BASE + 0x106;
	public static final int BPL1MOD		=	CUSTOM_BASE + 0x108;
	public static final int BPL2MOD		=	CUSTOM_BASE + 0x10A;
	public static final int BPLCON4		=	CUSTOM_BASE + 0x10C;
	public static final int CLXCON2		=	CUSTOM_BASE + 0x10E;

	public static final int BPL1DAT		=	CUSTOM_BASE + 0x110;
	public static final int BPL2DAT		=	CUSTOM_BASE + 0x112;
	public static final int BPL3DAT		=	CUSTOM_BASE + 0x114;
	public static final int BPL4DAT		=	CUSTOM_BASE + 0x116;
	public static final int BPL5DAT		=	CUSTOM_BASE + 0x118;
	public static final int BPL6DAT		=	CUSTOM_BASE + 0x11A;

	public static final int SPR0PTH		=	CUSTOM_BASE + 0x120;
	public static final int SPR0PTL		=	CUSTOM_BASE + 0x122;
	public static final int SPR1PTH		=	CUSTOM_BASE + 0x124;
	public static final int SPR1PTL		=	CUSTOM_BASE + 0x126;
	public static final int SPR2PTH		=	CUSTOM_BASE + 0x128;
	public static final int SPR2PTL		=	CUSTOM_BASE + 0x12A;
	public static final int SPR3PTH		=	CUSTOM_BASE + 0x12C;
	public static final int SPR3PTL		=	CUSTOM_BASE + 0x12E;
	public static final int SPR4PTH		=	CUSTOM_BASE + 0x130;
	public static final int SPR4PTL		=	CUSTOM_BASE + 0x132;
	public static final int SPR5PTH		=	CUSTOM_BASE + 0x134;
	public static final int SPR5PTL		=	CUSTOM_BASE + 0x136;
	public static final int SPR6PTH		=	CUSTOM_BASE + 0x138;
	public static final int SPR6PTL		=	CUSTOM_BASE + 0x13A;
	public static final int SPR7PTH		=	CUSTOM_BASE + 0x13C;
	public static final int SPR7PTL		=	CUSTOM_BASE + 0x13E;

	public static final int SPR0POS		=	CUSTOM_BASE + 0x140;
	public static final int SPR0CTL		=	CUSTOM_BASE + 0x142;
	public static final int SPR0DATA	=	CUSTOM_BASE + 0x144;
	public static final int SPR0DATB	=	CUSTOM_BASE + 0x146;

	public static final int SPR1POS		=	CUSTOM_BASE + 0x148;
	public static final int SPR1CTL		=	CUSTOM_BASE + 0x14A;
	public static final int SPR1DATA	=	CUSTOM_BASE + 0x14C;
	public static final int SPR1DATB	=	CUSTOM_BASE + 0x14E;

	public static final int SPR2POS		=	CUSTOM_BASE + 0x150;
	public static final int SPR2CTL		=	CUSTOM_BASE + 0x152;
	public static final int SPR2DATA	=	CUSTOM_BASE + 0x154;
	public static final int SPR2DATB	=	CUSTOM_BASE + 0x156;

	public static final int SPR3POS		=	CUSTOM_BASE + 0x158;
	public static final int SPR3CTL		=	CUSTOM_BASE + 0x15A;
	public static final int SPR3DATA	=	CUSTOM_BASE + 0x15C;
	public static final int SPR3DATB	=	CUSTOM_BASE + 0x15E;

	public static final int SPR4POS		=	CUSTOM_BASE + 0x160;
	public static final int SPR4CTL		=	CUSTOM_BASE + 0x162;
	public static final int SPR4DATA	=	CUSTOM_BASE + 0x164;
	public static final int SPR4DATB	=	CUSTOM_BASE + 0x166;

	public static final int SPR5POS		=	CUSTOM_BASE + 0x168;
	public static final int SPR5CTL		=	CUSTOM_BASE + 0x16A;
	public static final int SPR5DATA	=	CUSTOM_BASE + 0x16C;
	public static final int SPR5DATB	=	CUSTOM_BASE + 0x16E;

	public static final int SPR6POS		=	CUSTOM_BASE + 0x170;
	public static final int SPR6CTL		=	CUSTOM_BASE + 0x172;
	public static final int SPR6DATA	=	CUSTOM_BASE + 0x174;
	public static final int SPR6DATB	=	CUSTOM_BASE + 0x176;

	public static final int SPR7POS		=	CUSTOM_BASE + 0x178;
	public static final int SPR7CTL		=	CUSTOM_BASE + 0x17A;
	public static final int SPR7DATA	=	CUSTOM_BASE + 0x17C;
	public static final int SPR7DATB	=	CUSTOM_BASE + 0x17E;

	// SpriteDef
	public static final int SD_POS		=	0x00;
	public static final int SD_CTL		=	0x02;
	public static final int SD_DATAA	=	0x04;
	public static final int SD_DATAB	=	0x06;
	public static final int SD_SIZEOF	=	0x08;

	public static final int COLOR		=	CUSTOM_BASE + 0x180;
	public static final int COLOR00		=	CUSTOM_BASE + 0x180;
	public static final int COLOR01		=	CUSTOM_BASE + 0x182;
	public static final int COLOR02		=	CUSTOM_BASE + 0x184;
	public static final int COLOR03		=	CUSTOM_BASE + 0x186;
	public static final int COLOR04		=	CUSTOM_BASE + 0x188;
	public static final int COLOR05		=	CUSTOM_BASE + 0x18A;
	public static final int COLOR06		=	CUSTOM_BASE + 0x18C;
	public static final int COLOR07		=	CUSTOM_BASE + 0x18E;
	public static final int COLOR08		=	CUSTOM_BASE + 0x190;
	public static final int COLOR09		=	CUSTOM_BASE + 0x192;
	public static final int COLOR10		=	CUSTOM_BASE + 0x194;
	public static final int COLOR11		=	CUSTOM_BASE + 0x196;
	public static final int COLOR12		=	CUSTOM_BASE + 0x198;
	public static final int COLOR13		=	CUSTOM_BASE + 0x19A;
	public static final int COLOR14		=	CUSTOM_BASE + 0x19C;
	public static final int COLOR15		=	CUSTOM_BASE + 0x19E;
	public static final int COLOR16		=	CUSTOM_BASE + 0x1A0;
	public static final int COLOR17		=	CUSTOM_BASE + 0x1A2;
	public static final int COLOR18		=	CUSTOM_BASE + 0x1A4;
	public static final int COLOR19		=	CUSTOM_BASE + 0x1A6;
	public static final int COLOR20		=	CUSTOM_BASE + 0x1A8;
	public static final int COLOR21		=	CUSTOM_BASE + 0x1AA;
	public static final int COLOR22		=	CUSTOM_BASE + 0x1AC;
	public static final int COLOR23		=	CUSTOM_BASE + 0x1AE;
	public static final int COLOR24		=	CUSTOM_BASE + 0x1B0;
	public static final int COLOR25		=	CUSTOM_BASE + 0x1B2;
	public static final int COLOR26		=	CUSTOM_BASE + 0x1B4;
	public static final int COLOR27		=	CUSTOM_BASE + 0x1B6;
	public static final int COLOR28		=	CUSTOM_BASE + 0x1B8;
	public static final int COLOR29		=	CUSTOM_BASE + 0x1BA;
	public static final int COLOR30		=	CUSTOM_BASE + 0x1BC;
	public static final int COLOR31		=	CUSTOM_BASE + 0x1BE;

	public static final int HTOTAL		=	CUSTOM_BASE + 0x1c0;
	public static final int HSSTOP		=	CUSTOM_BASE + 0x1c2;
	public static final int HBSTRT		=	CUSTOM_BASE + 0x1c4;
	public static final int HBSTOP		=	CUSTOM_BASE + 0x1c6;
	public static final int VTOTAL		=	CUSTOM_BASE + 0x1c8;
	public static final int VSSTOP		=	CUSTOM_BASE + 0x1ca;
	public static final int VBSTRT		=	CUSTOM_BASE + 0x1cc;
	public static final int VBSTOP		=	CUSTOM_BASE + 0x1ce;
	public static final int SPRHSTRT	=	CUSTOM_BASE + 0x1d0;
	public static final int SPRHSTOP	=	CUSTOM_BASE + 0x1d2;
	public static final int BPLHSTRT	=	CUSTOM_BASE + 0x1d4;
	public static final int BPLHSTOP	=	CUSTOM_BASE + 0x1d6;
	public static final int HHPOSW		=	CUSTOM_BASE + 0x1d8;
	public static final int HHPOSR		=	CUSTOM_BASE + 0x1da;
	public static final int BEAMCON0	=	CUSTOM_BASE + 0x1dc;
	public static final int HSSTRT		=	CUSTOM_BASE + 0x1de;
	public static final int VSSTRT		=	CUSTOM_BASE + 0x1e0;
	public static final int HCENTER		=	CUSTOM_BASE + 0x1e2;
	public static final int DIWHIGH		=	CUSTOM_BASE + 0x1e4;
	public static final int FMODE		=	CUSTOM_BASE + 0x1fc;
}
