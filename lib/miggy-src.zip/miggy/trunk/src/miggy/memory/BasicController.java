package miggy.memory;

import miggy.api.cpu.Size;
import miggy.api.memory.AddressSpace;
import miggy.api.config.MachineDefinition;
import miggy.api.config.ConfigurationException;

import java.nio.ByteBuffer;
import java.util.logging.Logger;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public abstract class BasicController implements AddressSpace
{
	private static Logger logger = Logger.getLogger("Miggy.Memory.Basic");
	protected final int baseAddress;
	protected final ByteBuffer buffer;
	protected final int size;

	public BasicController(int baseAddress, int size)
	{
		this.baseAddress = baseAddress;
		this.size = size;
		this.buffer = ByteBuffer.allocateDirect(size);
	}

	/**
	 * Initialise the controller
	 *
	 * @param config Configuration object containing machine settings
	 * @throws miggy.api.config.ConfigurationException
	 *          if Configuration holds invalid information for this component
	 */
	public void init(MachineDefinition config) throws ConfigurationException
	{
	}

	public int peek(int address, Size size)
	{
		int val;

		switch(size)
		{
			case Byte:
			{
				val = buffer.get(address - baseAddress);
				break;
			}
			case Word:
			{
				val = buffer.getShort(address - baseAddress);
				break;
			}
			case Long:
			{
				val = buffer.getInt(address - baseAddress);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
		return val & size.mask();
	}

	public void poke(int address, int value, Size size)
	{
		address -= baseAddress;
		switch(size)
		{
			case Byte:
			{
				buffer.put(address, (byte)value);
				break;
			}
			case Word:
			{
				buffer.putShort(address, (short)value);
				break;
			}
			case Long:
			{
				buffer.putInt(address, value);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
	}

	public int directPeek(int address, Size size)
	{
		int val;

		switch(size)
		{
			case Byte:
			{
				val = buffer.get(address - baseAddress);
				break;
			}
			case Word:
			{
				val = buffer.getShort(address - baseAddress);
				break;
			}
			case Long:
			{
				val = buffer.getInt(address - baseAddress);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
		return val & size.mask();
	}

	public void directPoke(int address, int value, Size size)
	{
		address -= baseAddress;
		switch(size)
		{
			case Byte:
			{
				buffer.put(address, (byte)value);
				break;
			}
			case Word:
			{
				buffer.putShort(address, (short)value);
				break;
			}
			case Long:
			{
				buffer.putInt(address, value);
				break;
			}
			default:
				throw new IllegalArgumentException("Invalid data size specified");
		}
	}
}
