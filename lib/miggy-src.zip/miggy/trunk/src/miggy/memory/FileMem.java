package miggy.memory;

import miggy.api.cpu.Size;
import miggy.api.memory.AddressSpace;
import miggy.api.config.MachineDefinition;
import miggy.api.config.ConfigurationException;
import miggy.utils.TextUtil;

import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.logging.Logger;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class FileMem implements AddressSpace
{
	private static Logger logger = Logger.getLogger(FileMem.class.getName());
	private ByteBuffer buf;
	private final int baseAddr;

	private FileMem(int baseAddr)
	{
		this.baseAddr = baseAddr;
	}

	/**
	 * Initialise the controller
	 *
	 * @param config Configuration object containing machine settings
	 * @throws miggy.api.config.ConfigurationException
	 *          if Configuration holds invalid information for this component
	 */
	public void init(MachineDefinition config) throws ConfigurationException
	{
	}

	public void reset()
	{
	}

	public static FileMem create(File f, int baseAddr)
	{
		FileMem rm = new FileMem(baseAddr);
		try
		{
			rm.buf = ByteBuffer.allocate((int)f.length());

			FileInputStream fis = new FileInputStream(f);
			FileChannel fc = fis.getChannel();

			int count = fc.read(rm.buf);
			logger.fine("Read " + count + " bytes");
			fc.close();
			rm.buf.rewind();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return rm;
	}

	public byte peekByte(int address)
	{
		return buf.get(address - baseAddr);
	}

	public short peekWord(int address)
	{
		return buf.getShort(address - baseAddr);
	}

	public int peekLong(int address)
	{
		return buf.getInt(address - baseAddr);
	}

	public void pokeByte(int address, byte value)
	{
		buf.put(address - baseAddr, value);
	}

	public void pokeWord(int address, short value)
	{
		buf.putShort(address - baseAddr, value);
	}

	public void pokeLong(int address, int value)
	{
		buf.putInt(address - baseAddr, value);
	}

	public int peek(int address, Size size)
	{
		address -= baseAddr;
		switch(size)
		{
			case Byte:
				return buf.get(address);
			case Word:
				return buf.getShort(address);
			case Long:
				return buf.getInt(address);
		}
		throw new IllegalArgumentException("Invalid data size specified");
	}

	public void poke(int address, int value, Size size)
	{
		address -= baseAddr;
		switch(size)
		{
			case Byte:
				buf.put(address, (byte)value);
				break;
			case Word:
				buf.putShort(address, (short)value);
				break;
			case Long:
				buf.putInt(address, value);
				break;
		}
	}

	public int directPeek(int address, Size size)
	{
		address -= baseAddr;
		switch(size)
		{
			case Byte:
				return buf.get(address);
			case Word:
				return buf.getShort(address);
			case Long:
				return buf.getInt(address);
		}
		throw new IllegalArgumentException("Invalid data size specified");
	}

	public void directPoke(int address, int value, Size size)
	{
		address -= baseAddr;
		switch(size)
		{
			case Byte:
				buf.put(address, (byte)value);
				break;
			case Word:
				buf.putShort(address, (short)value);
				break;
			case Long:
				buf.putInt(address, value);
				break;
		}
	}


	public byte debugPeekByte(int address)
	{
		logger.finest("Debug reading byte at " + TextUtil.toHex(address));
		return buf.get(address);
	}

	public short debugPeekWord(int address)
	{
		logger.finest("Debug reading word at " + TextUtil.toHex(address));
		return buf.getShort(address);
	}

	public int debugPeekLong(int address)
	{
		logger.finest("Debug reading long at " + TextUtil.toHex(address));
		return buf.getInt(address );
	}

	public void debugPokeByte(int address, byte value)
	{
		logger.finest("Debug writing byte at " + TextUtil.toHex(address));
		buf.put(address, value);
	}

	public void debugPokeWord(int address, short value)
	{
		logger.finest("Debug writing word at " + TextUtil.toHex(address));
		buf.putShort(address, value);
	}

	public void debugPokeLong(int address, int value)
	{
		logger.finest("Debug writing long at " + TextUtil.toHex(address));
		buf.putInt(address, value);
	}
}
