package miggy.hardware;

// $Revision: 21 $
public abstract class CIABase implements CIA8520
{
	protected byte pra;
	protected byte prb;
	protected byte ddra;
	protected byte ddrb;
	protected byte talo;
	protected byte tahi;
	protected byte tblo;
	protected byte tbhi;
	protected byte todlow;
	protected byte todmid;
	protected byte todhi;
	protected byte sdr;
	protected byte icr;
	protected byte cra;
	protected byte crb;

	protected boolean taRunning;
	protected boolean taPBON;
	protected boolean taToggleMode;
	protected boolean taOneShotMode;
	protected boolean taCNT;
	protected boolean taSPOut;

	protected boolean tbRunning;
	protected boolean tbPBON;
	protected boolean tbToggleMode;
	protected boolean tbOneShotMode;
	protected int tbInputMode;
	protected boolean tbAlarmSwitch;

	public void reset()
	{
		pra = 0;
		prb = 0;
		ddra = 0;
		ddrb = 0;
		talo = 0;
		tahi = 0;
		tblo = 0;
		tbhi = 0;
		todlow = 0;
		todmid = 0;
		todhi = 0;
		sdr = 0;
		icr = 0;
		cra = 0;
		crb = 0;
		taRunning = false;
		taPBON = false;
		taToggleMode = false;
		taOneShotMode = false;
		taCNT = false;
		taSPOut = false;

		tbRunning = false;
		tbPBON = false;
		tbToggleMode = false;
		tbOneShotMode = false;
		tbInputMode = 0;
		tbAlarmSwitch = false;
	}

	public byte getRegisterA()
	{
		return pra;
	}

	public byte getRegisterB()
	{
		return prb;
	}

	public byte getDirectionA()
	{
		return ddra;
	}

	public byte getDirectionB()
	{
		return ddrb;
	}

	public byte getTimerALo()
	{
		return talo;
	}

	public byte getTimerAHi()
	{
		return tahi;
	}

	public byte getTimerBLo()
	{
		return tblo;
	}

	public byte getTimerBHi()
	{
		return tbhi;
	}

	public byte getCounterLo()
	{
		return todlow;
	}

	public byte getCounterMid()
	{
		return todmid;
	}

	public byte getCounterHi()
	{
		return todhi;
	}

	public byte getSDR()
	{
		return sdr;
	}

	public byte getICR()
	{
		return icr;
	}

	public void setControlA(byte value)
	{
		enableTimerA((value & 0x01) != 0);
		taPBON = ((value & 0x02) != 0);
		taToggleMode = ((value & 0x04) != 0);
		taOneShotMode = ((value & 0x08) != 0);
		if((value & 0x10) != 0)
		{
			//todo: force load - strobe input
		}
		taCNT = ((value & 0x20) != 0);
		taSPOut = ((value & 0x40) != 0);
	}

	public void setControlB(byte value)
	{
		enableTimerB((value & 0x01) != 0);
		tbPBON = ((value & 0x02) != 0);
		tbToggleMode = ((value & 0x04) != 0);
		tbOneShotMode = ((value & 0x08) != 0);
		if((value & 0x10) != 0)
		{
			//todo: force load - strobe input
		}
		tbInputMode = (value & 0x60) >> 5;
		tbAlarmSwitch = ((value & 0x80) != 0);
	}

	public byte getControlA()
	{
		return cra;
	}

	public byte getControlB()
	{
		return crb;
	}

	protected void enableTimerA(boolean start)
	{
		if(start && !taRunning)
		{
			//todo: start timer A
		}
		else if(!start && taRunning)
		{
			//todo: stop timer A
		}
		taRunning = start;
	}

	protected void enableTimerB(boolean start)
	{
		if(start && !tbRunning)
		{
			//todo: start timer B
		}
		else if(!start && tbRunning)
		{
			//todo: stop timer B
		}
		tbRunning = start;
	}
}
