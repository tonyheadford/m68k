package miggy.hardware;

// $Revision: 21 $
public class CIAA extends CIABase
{
	public CIAA()
	{
		reset();
	}

	public void update(int frameTime)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setRegisterA(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setRegisterB(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setDirectionA(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setDirectionB(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setTimerALo(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setTimerAHi(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setTimerBLo(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setTimerBHi(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setCounterLo(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setCounterMid(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setCounterHi(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setSDR(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setICR(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setControlA(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}

	public void setControlB(byte value)
	{
		//To change body of implemented methods use File | Settings | File Templates.
	}
}
