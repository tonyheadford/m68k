package miggy.hardware;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public interface CIA8520
{
	public void update(int frameTime);
	public void reset();
	public void setRegisterA(byte value);
	public byte getRegisterA();
	public void setRegisterB(byte value);
	public byte getRegisterB();
	public void setDirectionA(byte value);
	public byte getDirectionA();
	public void setDirectionB(byte value);
	public byte getDirectionB();
	public void setTimerALo(byte value);
	public void setTimerAHi(byte value);
	public void setTimerBLo(byte value);
	public void setTimerBHi(byte value);
	public byte getTimerALo();
	public byte getTimerAHi();
	public byte getTimerBLo();
	public byte getTimerBHi();
	public void setCounterLo(byte value);
	public void setCounterMid(byte value);
	public void setCounterHi(byte value);
	public byte getCounterLo();
	public byte getCounterMid();
	public byte getCounterHi();
	public void setSDR(byte value);
	public byte getSDR();
	public void setICR(byte value);
	public byte getICR();
	public void setControlA(byte value);
	public byte getControlA();
	public void setControlB(byte value);
	public byte getControlB();
}
