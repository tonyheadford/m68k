package miggy.api.machine;

import miggy.api.machine.MachineState;

// $Revision: 21 $
public interface MachineListener
{
	public void stateChange(MachineState state);
	public void exit();
}
