package miggy.api.cpu;

import miggy.SystemModel;
import miggy.api.cpu.MC680x0;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public enum ConditionCode
{
	T("t", 0), F("f", 1), HI("hi", 2), LS("ls", 3), CC("cc", 4), CS("cs", 5), NE("ne", 6), EQ("eq", 7), VC("vc", 8),
	VS("vs", 9), PL("pl", 10), MI("mi", 11), GE("ge", 12), LT("lt", 13), GT("gt", 14), LE("le", 15);

	private final String mnemonic;
	private final int code;

	private ConditionCode(String mnemonic, int code)
	{
		this.mnemonic = mnemonic;
		this.code = code;
	}

	public String mnemonic() { return mnemonic; }
	public int code() { return code; }
	
	@Override public String toString() { return mnemonic; }

	public static boolean test(ConditionCode cc)
	{
		int ccr = SystemModel.CPU.getSR() & 0x001f;

		switch(cc)
		{
			case T:
			{
				return true;
			}
			case F:
			{
				return false;
			}
			case HI:
			{
				return ((ccr & (MC680x0.C_FLAG | MC680x0.Z_FLAG)) == 0);
			}
			case LS:
			{
				return ((ccr & (MC680x0.C_FLAG | MC680x0.Z_FLAG)) != 0);
			}
			case CC:
			{
				return ((ccr & MC680x0.C_FLAG) == 0);
			}
			case CS:
			{
				return ((ccr & MC680x0.C_FLAG) != 0);
			}
			case NE:
			{
				return ((ccr & MC680x0.Z_FLAG) == 0);
			}
			case EQ:
			{
				return ((ccr & MC680x0.Z_FLAG) != 0);
			}
			case VC:
			{
				return ((ccr & MC680x0.V_FLAG) == 0);
			}
			case VS:
			{
				return ((ccr & MC680x0.V_FLAG) != 0);
			}
			case PL:
			{
				return ((ccr & MC680x0.N_FLAG) == 0);
			}
			case MI:
			{
				return ((ccr & MC680x0.N_FLAG) != 0);
			}
			case GE:
			{
				int v = ccr & (MC680x0.N_FLAG | MC680x0.V_FLAG);
				return (v == 0 || v == (MC680x0.N_FLAG | MC680x0.V_FLAG));
			}
			case LT:
			{
				int v = ccr & (MC680x0.N_FLAG | MC680x0.V_FLAG);
				return (v == MC680x0.N_FLAG || v == MC680x0.V_FLAG);
			}
			case GT:
			{
				int v = ccr & (MC680x0.N_FLAG | MC680x0.V_FLAG | MC680x0.Z_FLAG);
				return (v == 0 || v == (MC680x0.N_FLAG | MC680x0.V_FLAG));
			}
			case LE:
			{
				int v = ccr & (MC680x0.N_FLAG | MC680x0.V_FLAG | MC680x0.Z_FLAG);
				return ((v & MC680x0.Z_FLAG) != 0 || (v == MC680x0.N_FLAG) || (v == MC680x0.V_FLAG));
			}
		}
		throw new IllegalArgumentException("Invalid ConditionCode value!");
	}
}
