package miggy.api.cpu;

// $Revision: 21 $
public interface DecodedInstruction
{
	String name();

	int opcode();

	int address();

	Size opsize();

	Operand src();

	Operand dst();

	int getData();

	boolean usesData();
}
