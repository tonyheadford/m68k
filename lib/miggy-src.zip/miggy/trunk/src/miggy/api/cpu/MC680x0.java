package miggy.api.cpu;

import miggy.api.config.ConfigurationException;
import miggy.api.config.MachineDefinition;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public interface MC680x0
{
	//user byte flags - condition code register (ccr) lower byte of status register
	public static final int C_FLAG		= 0x0001;
	public static final int C_FLAG_MASK	= 0xFFFE;
	public static final int V_FLAG		= 0x0002;
	public static final int V_FLAG_MASK	= 0xFFFD;
	public static final int Z_FLAG		= 0x0004;
	public static final int Z_FLAG_MASK	= 0xFFFB;
	public static final int N_FLAG		= 0x0008;
	public static final int N_FLAG_MASK	= 0xFFF7;
	public static final int X_FLAG		= 0x0010;
	public static final int X_FLAG_MASK	= 0xFFEF;

	//system byte flags - status register (sr) upper byte of status register
	public static final int TRACE_FLAG		= 0x8000;
	public static final int TRACE_FLAG_MASK	= 0x7FFF;
	public static final int SUPER_FLAG		= 0x2000;
	public static final int SUPER_FLAG_MASK	= 0xDFFF;
	public static final int INT_FLAGS		= 0x0700;
	public static final int INT_FLAGS_MASK	= 0xF8FF;

	//addressing modes
	public static final int ADDR_DREG		= 0;
	public static final int ADDR_AREG		= 1;
	public static final int ADDR_AIND		= 2;
	public static final int ADDR_AIPI		= 3;
	public static final int ADDR_AIPD		= 4;
	public static final int ADDR_AD16		= 5;
	public static final int ADDR_AD8R		= 6;
	public static final int ADDR_MOD7		= 7;

	public static final int MOD7_AB16		= 0;
	public static final int MOD7_AB32		= 1;
	public static final int MOD7_PC16		= 2;
	public static final int MOD7_PC8R		= 3;
	public static final int MOD7_IMSR		= 4;

	public static final int AD8R_AREG		= 0x8000;
	public static final int AD8R_SIZE		= 0x0800;

	public void init(MachineDefinition config) throws ConfigurationException;

	public int getDataRegister(int n);
	public int getDataRegister(int n, Size size);

	public void setDataRegister(int n, int value);
	public void setDataRegister(int n, int value, Size size);

	public int getAddrRegister(int n);
	public int getAddrRegister(int n, Size size);

	public void setAddrRegister(int n, int value);
	public void setAddrRegister(int n, int value, Size size);

	public int getPC();
	public void setPC(int address);

	public short getSR();
	public void setSR(short value);

	public byte getCCR();
	public void setCCR(byte value);

	public int fetch(Size size);

	public void setFlag(CpuFlag flag);
	public void clrFlag(CpuFlag flag);

	public boolean isSet(CpuFlag flag);
	public boolean isClr(CpuFlag flag);

	public int execute();
	public Instruction getInstruction(int opcode);

	public void push(int value, Size size);
	public int pop(Size size);

	public int getUSP();
	public void setUSP(int address);
	
	public int getSSP();
	public void setSSP(int address);

	public void setSupervisorMode(boolean enable);
	public boolean isSupervisorMode();

	public int getCurrentInstructionAddress();

	public void raiseException(int vector);
	public void raiseSRException();
	public void raiseInterrupt(int priority);
	public void reset();
}
