package miggy.api.cpu;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public enum Size
{
	Byte(1, 2, 0x00ff,".b", 0x0080, 8), Word(2, 2, 0x0000ffff,".w",0x00008000, 16),
		Long(4, 4, 0xffffffff,".l",0x80000000, 32), Unsized(0, 0,0,"",0, 0);

	private final int readSize;
	private final int byteSize;
	private final int mask;
	private final String ext;
	private final int msb;
	private final int bitsize;

	Size(int byteSize, int readSize, int mask, String ext, int msb, int bitsize)
	{
		this.byteSize = byteSize;
		this.readSize = readSize;
		this.mask = mask;
		this.ext = ext;
		this.msb = msb;
		this.bitsize = bitsize;
	}

	public final int byteSize()
	{
		return byteSize;
	}

	public final int readSize()
	{
		return readSize;
	}

	public final int mask()
	{
		return mask;
	}

	public final String ext()
	{
		return ext;
	}

	public final int msb()
	{
		return msb;
	}

	public final int bitSize()
	{
		return bitsize;
	}

	public final int signExtend(int value)
	{
		return (((value & msb) != 0) ? (value | ~(mask)) : value);
	}
}
