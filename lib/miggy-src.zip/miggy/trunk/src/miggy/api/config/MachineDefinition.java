package miggy.api.config;

import miggy.api.display.VideoMode;

// $Revision: 21 $
public interface MachineDefinition
{
	public String getRegisterControllerName();
	public String getCpuName();
	public String getMemoryControllerName();
	public String getDmaControllerName();
	public String getDisplayControllerName();
	public String getDefinitionName();
	public int getChipRamSize();
	public int getSlowRamSize();
	public int getFastRamSize();
	public String getRomFilename();
	public boolean hasRealTimeClock();
	public VideoMode getVideoMode();
	public int getClockSpeed();
	public String getString(String key) throws ConfigurationException;
	public int getInt(String key) throws ConfigurationException;
	public boolean getBool(String key) throws ConfigurationException;
	public String getStringDefault(String key, String def);
	public int getIntDefault(String key, int def);
	public boolean getBoolDefault(String key, boolean def);
}
