package miggy.api.display;

import miggy.api.config.MachineDefinition;
import miggy.api.config.ConfigurationException;

// $Revision: 21 $
public interface DisplayController
{
	/**
	 * Initialise the controller
	 * @param config Configuration parameters
	 * @throws miggy.api.config.ConfigurationException if Configuration holds invalid information for this component
	 */
	void init(MachineDefinition config) throws ConfigurationException;
	public void reset();
	public void endFrame();
	public void displayClosing();
}
