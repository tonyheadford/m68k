package miggy.api.memory;

// $Revision: 21 $
public interface MappedSpace extends AddressSpace
{
	int getSize();
	int getBaseAddress();
}
