package miggy.cpu.operands;

import miggy.api.cpu.Size;
import miggy.SystemModel;
import miggy.api.cpu.Operand;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public class OperandFactory
{
	private static final Operand _IllegalOperand = new IllegalOperand();
	private static final Operand _UnusedOperand = new UnusedOperand();

	public static Operand IllegalOperand()
	{
		return _IllegalOperand;
	}
	public static Operand UnusedOperand()
	{
		return _UnusedOperand;
	}

	public static Operand dataReg(int reg)
	{
		return new DataRegister(reg);
	}

	public static Operand addrReg(int reg)
	{
		return new AddressRegister(reg);
	}

	public static Operand addrRegIndPostInc(int reg)
	{
		return new AddressRegisterIndirectPostInc(reg);
	}

	public static Operand addrIndDisplace(int reg, int displacement)
	{
		return new AddressRegisterIndirectDisplace(reg, displacement);
	}

	public static Operand displacement(int displacement, Size size)
	{
		return new Displacement(displacement, size);
	}

	public static Operand addrRegIndPreDec(int reg)
	{
		return new AddressRegisterIndirectPreDec(reg);
	}

	public static Operand regList(int bitmask, boolean reversed)
	{
		return new RegisterList(bitmask, reversed);
	}

	public static Operand usp()
	{
		return new UserStackPointer();
	}

	public static Operand ccr()
	{
		return new ConditionCodeRegister();
	}
	
	public static Operand sr()
	{
		return new StatusRegister();
	}

	public static Operand literal(int value)
	{
		return new LiteralValue(value);
	}

	public static Operand immediate(int value, Size size)
	{
		switch(size)
		{
			case Byte:
				return new Immediate8(value);
			case Word:
				return new Immediate16(value);
			case Long:
				return new Immediate32(value);
		}
		return _IllegalOperand;
	}


	//for executing
	public static Operand fetchOperand(int mode, int reg, boolean isSrcOperand, Size size)
	{
		Operand op;

		switch(mode)
		{
			case 0:
			{
				op = new DataRegister(reg);
				break;
			}
			case 1:
			{
				op = new AddressRegister(reg);
				break;
			}
			case 2:
			{
				op = new AddressRegisterIndirect(reg);
				break;
			}
			case 3:
			{
				op = new AddressRegisterIndirectPostInc(reg);
				break;
			}
			case 4:
			{
				op = new AddressRegisterIndirectPreDec(reg);
				break;
			}
			case 5:
			{
				op = new AddressRegisterIndirectDisplace(reg, (short)SystemModel.CPU.fetch(Size.Word));
				break;
			}
			case 6:
			{
				int x = SystemModel.CPU.fetch(Size.Word);
				// reg, displacement, index reg, is addr reg, is long
				op = new AddressRegisterIndirectIndex(reg, (byte)(x & 0x00ff), (x & 0x7000) >> 12, (x & 0x8000) != 0, (x & 0x0800) != 0);
				break;
			}
			case 7:
			{
				switch(reg)
				{
					case 0:
					{
						op = new AbsoluteShort(SystemModel.CPU.fetch(Size.Word));
						break;
					}
					case 1:
					{
						op = new AbsoluteLong(SystemModel.CPU.fetch(Size.Long));
						break;
					}
					case 2:
					{
						op = new PCDisplace((short)SystemModel.CPU.fetch(Size.Word));
						break;
					}
					case 3:
					{
						int x = SystemModel.CPU.fetch(Size.Word);
						//index, index reg, is addr reg, is long
						op = new PCIndex((byte)(x & 0x00ff), (x & 0x7000) >> 12, (x & 0x8000) != 0, (x & 0x0800) != 0);
						break;
					}
					case 4:
					{
						if(isSrcOperand)
						{
							switch(size)
							{
								case Byte:
								{
									op = new Immediate8(SystemModel.CPU.fetch(Size.Word) & 0x00ff);
									break;
								}
								case Word:
								{
									op = new Immediate16(SystemModel.CPU.fetch(Size.Word));
									break;
								}
								case Long:
								{
									op = new Immediate32(SystemModel.CPU.fetch(Size.Long));
									break;
								}
								default:
								{
									op = _IllegalOperand;
									break;
								}
							}
						}
						else
						{
							if(size == Size.Byte)
							{
								op = new ConditionCodeRegister();
							}
							else if(size == Size.Word)
							{
								op = new StatusRegister();
							}
							else
							{
								op = _IllegalOperand;
							}
						}
						break;
					}
					default:
					{
						op = _IllegalOperand;
						break;
					}
				}
				break;
			}
			default:
			{
				op = _IllegalOperand;
				break;
			}
		}
		return op;
	}


	// for disassembling
	public static Operand valueOf(int address, int mode, int reg, boolean isSrcOperand, Size size)
	{
		Operand op;

		switch(mode)
		{
			case 0:
			{
				op = new DataRegister(reg);
				break;
			}
			case 1:
			{
				op = new AddressRegister(reg);
				break;
			}
			case 2:
			{
				op = new AddressRegisterIndirect(reg);
				break;
			}
			case 3:
			{
				op = new AddressRegisterIndirectPostInc(reg);
				break;
			}
			case 4:
			{
				op = new AddressRegisterIndirectPreDec(reg);
				break;
			}
			case 5:
			{
				//signed displacement
				op = new AddressRegisterIndirectDisplace(reg, (short)SystemModel.MEM.peek(address, Size.Word));
				break;
			}
			case 6:
			{
				int x = SystemModel.MEM.peek(address, Size.Word);

				// reg, signed displacement, index reg, is addr reg, is long
				op = new AddressRegisterIndirectIndex(reg, (byte)(x & 0x00ff), (x & 0x7000) >> 12, (x & 0x8000) != 0, (x & 0x0800) != 0);
				break;
			}
			case 7:
			{
				switch(reg)
				{
					case 0:
					{
						op = new AbsoluteShort(SystemModel.MEM.peek(address, Size.Word));
						break;
					}
					case 1:
					{
						op = new AbsoluteLong(SystemModel.MEM.peek(address, Size.Long));
						break;
					}
					case 2:
					{
						//signed displacement
						op = new PCDisplace((short)SystemModel.MEM.peek(address, Size.Word));
						break;
					}
					case 3:
					{
						int x = SystemModel.MEM.peek(address, Size.Word);
						//signed displacement, index reg, is addr reg, is long
						op = new PCIndex((byte)(x & 0x00ff), (x & 0x7000) >> 12, (x & 0x8000) != 0, (x & 0x0800) != 0);
						break;
					}
					case 4:
					{
						if(isSrcOperand)
						{
							switch(size)
							{
								case Byte:
								{
									op = new Immediate8(SystemModel.MEM.peek(address, Size.Word) & 0x00ff);
									break;
								}
								case Word:
								{
									op = new Immediate16(SystemModel.MEM.peek(address, Size.Word));
									break;
								}
								case Long:
								{
									op = new Immediate32(SystemModel.MEM.peek(address, Size.Long));
									break;
								}
								default:
								{
									op = _IllegalOperand;
									break;
								}
							}
						}
						else
						{
							if(size == Size.Byte)
							{
								op = new ConditionCodeRegister();
							}
							else if(size == Size.Word)
							{
								op = new StatusRegister();
							}
							else
							{
								op = _IllegalOperand;
							}
						}
						break;
					}
					default:
					{
						op = _IllegalOperand;
						break;
					}
				}
				break;
			}
			default:
			{
				op = _IllegalOperand;
				break;
			}
		}
		return op;
	}
}
