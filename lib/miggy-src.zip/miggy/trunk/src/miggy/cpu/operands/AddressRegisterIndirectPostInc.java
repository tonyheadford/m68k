package miggy.cpu.operands;

import miggy.api.cpu.Size;
import miggy.SystemModel;
import miggy.api.cpu.Operand;
import miggy.api.cpu.EffectiveAddress;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class AddressRegisterIndirectPostInc implements Operand
{
	private final int reg;
	private boolean accessed;
	private int addr;

	public AddressRegisterIndirectPostInc(int reg)
	{
		this.reg = reg;
		accessed = false;
	}

	public final int get(Size size)
	{
		if(!accessed)
		{
			int address = SystemModel.CPU.getAddrRegister(reg);
			if(reg == 7 && size == Size.Byte)
				SystemModel.CPU.setAddrRegister(reg, address + 2);
			else
				SystemModel.CPU.setAddrRegister(reg, address + size.byteSize());

			addr = address;
			accessed = true;
		}
		return SystemModel.MEM.peek(addr, size);
	}

	public final void put(int value, Size size)
	{
		if(!accessed)
		{
			int address = SystemModel.CPU.getAddrRegister(reg);
			if(reg == 7 && size == Size.Byte)
				SystemModel.CPU.setAddrRegister(reg, address + 2);
			else
				SystemModel.CPU.setAddrRegister(reg, address + size.byteSize());

			addr = address;
			accessed = true;
		}
		SystemModel.MEM.poke(addr, value, size);
	}

	public final int offset()
	{
		return 0;
	}

	public final int timing(Size size)
	{
		return (size == Size.Long ? 8 : 4);
	}

	public final boolean isRegister()
	{
		return false;
	}

	public final EffectiveAddress type()
	{
		return EffectiveAddress.AddrRegIndPostInc;
	}

	public final int putMultiple(int reglist, Size size)
	{
		int address = SystemModel.CPU.getAddrRegister(reg);
		int result = OperandHelper.putMultiple(reglist, address, size);
		//increment the address
		SystemModel.CPU.setAddrRegister(reg, address + (result * size.byteSize()));
		return result;
	}

	public final int getMultiple(int reglist, Size size)
	{
		int address = SystemModel.CPU.getAddrRegister(reg);
		int result = OperandHelper.getMultiple(reglist, address, size);
		//increment the address
		SystemModel.CPU.setAddrRegister(reg, address + (result * size.byteSize()));
		return result;
	}

	public final int computedAddress()
	{
		//not used when this type of access is required (ie. JSR)
		return 0;
	}

	@Override public String toString()
	{
		return "(a" + reg + ")+";
	}
}
