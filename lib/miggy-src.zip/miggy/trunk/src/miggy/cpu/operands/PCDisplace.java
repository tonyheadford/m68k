package miggy.cpu.operands;

import miggy.api.cpu.Size;
import miggy.SystemModel;
import miggy.api.cpu.Operand;
import miggy.api.cpu.EffectiveAddress;
import miggy.utils.TextUtil;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class PCDisplace implements Operand
{
	private final int displacement;

	public PCDisplace(int displacement)
	{
		//signed word displacement
		if((displacement & 0x8000) != 0 && displacement >= 0)
		{
			throw new IllegalArgumentException("displacement must be sign extended");
		}
		this.displacement = displacement;
	}

	public final int get(Size size)
	{
		//PC is taken at the start of the displacement so we sub 2 bytes for fetching the displacement
		return SystemModel.MEM.peek(SystemModel.CPU.getPC() + displacement - 2, size);
	}

	public final void put(int value, Size size)
	{
		//PC is taken at the start of the displacement so we sub 2 bytes for fetching the displacement
		SystemModel.MEM.poke(SystemModel.CPU.getPC() + displacement - 2, value, size);
	}

	public final int offset()
	{
		//16-bit read after instruction
		return 2;
	}

	public final int timing(Size size)
	{
		return (size == Size.Long ? 12 : 8);
	}

	public final boolean isRegister()
	{
		return false;
	}

	public EffectiveAddress type()
	{
		return EffectiveAddress.PCIndDis;
	}

	public final int putMultiple(int reglist, Size size)
	{
		//PC is taken at the start of the displacement so we sub 2 bytes for fetching the displacement
		return OperandHelper.putMultiple(reglist, SystemModel.CPU.getPC() + displacement - 2, size);
	}

	public final int getMultiple(int reglist, Size size)
	{
		//PC is taken at the start of the displacement so we sub 2 bytes for fetching the displacement
		return OperandHelper.getMultiple(reglist, SystemModel.CPU.getPC() + displacement - 2, size);
	}

	public final int computedAddress()
	{
		//PC is taken at the start of the displacement so we sub 2 bytes for fetching the displacement
		return SystemModel.CPU.getPC() + displacement - 2;
	}

	@Override public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append('$');
		sb.append(TextUtil.toHexParam(displacement, Size.Word, true));
		sb.append("(pc)");
		return sb.toString();
	}
}
