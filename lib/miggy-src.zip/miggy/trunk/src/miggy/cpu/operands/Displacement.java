package miggy.cpu.operands;

import miggy.api.cpu.Size;
import miggy.api.cpu.IllegalOperationException;
import miggy.api.cpu.EffectiveAddress;
import miggy.utils.TextUtil;
import miggy.api.cpu.Operand;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public class Displacement implements Operand
{
	private final int value;
	private final Size size;

	public Displacement(int value, Size size)
	{
		//signed displacement
		if((value & size.msb()) != 0 && value > 0)
		{
			throw new IllegalArgumentException("displacement must be sign extended");
		}
		this.value = value;
		this.size = size;
	}

	public final int get(Size size)
	{
		//no masking ?
		return value & this.size.mask();
	}

	public final void put(int value, Size size)
	{
		//doesn't make sense to put a value for immediate data
		throw new IllegalOperationException("Displacement is source only");
	}

	public final int offset()
	{
		//16-bit read after instruction
		if(size == Size.Word)
			return 2;

		return 0;
	}

	public final int timing(Size size)
	{
		return 0;
	}

	public final boolean isRegister()
	{
		return false;
	}

	public EffectiveAddress type()
	{
		return EffectiveAddress.NotEA;
	}

	public final int putMultiple(int reglist, Size size)
	{
		throw new IllegalOperationException("Displacement is not a valid operand for MOVEM");
	}

	public final int getMultiple(int reglist, Size size)
	{
		throw new IllegalOperationException("Displacement is not a valid operand for MOVEM");
	}

	public final int computedAddress()
	{
		//not used when this type of access is required (ie. JSR)
		return 0;
	}

	@Override public String toString()
	{
		return "$" + TextUtil.toHexParam(value, size, true);
	}
}
