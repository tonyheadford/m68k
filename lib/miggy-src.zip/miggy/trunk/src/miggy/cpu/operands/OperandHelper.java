package miggy.cpu.operands;

import miggy.api.cpu.Size;
import miggy.SystemModel;

// $Revision: 21 $
public class OperandHelper
{
	public static int putMultiple(int reglist, int address, Size size)
	{
		int bit = 1;
		int regcount = 0;
		int start = address;

		//assumes d0 is first bit
		for(int n = 0; n < 8; n++)
		{
			if((reglist & bit) != 0)
			{
				SystemModel.MEM.poke(start, SystemModel.CPU.getDataRegister(n), size);
				start += size.byteSize();
				regcount++;
			}
			bit <<= 1;
		}

		for(int n = 0; n < 8; n++)
		{
			if((reglist & bit) != 0)
			{
				SystemModel.MEM.poke(start, SystemModel.CPU.getAddrRegister(n), size);
				start += size.byteSize();
				regcount++;
			}
			bit <<= 1;
		}

		return regcount;
	}

	public static int getMultiple(int reglist, int address, Size size)
	{
		int bit = 1;
		int regcount = 0;
		int start = address;

		if(size == Size.Word)
		{
			//assumes d0 is first bit
			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//ensure these are sign extended properly
					SystemModel.CPU.setDataRegister(n, (short)SystemModel.MEM.peek(start, size));
					start += 2;
					regcount++;
				}
				bit <<= 1;
			}

			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//to ensure these are sign extended properly
					SystemModel.CPU.setAddrRegister(n, (short)SystemModel.MEM.peek(start, size));
					start += 2;
					regcount++;
				}
				bit <<= 1;
			}
		}
		else
		{
			//assumes d0 is first bit
			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//to ensure these are sign extended properly
					SystemModel.CPU.setDataRegister(n, SystemModel.MEM.peek(start, size));
					start += 4;
					regcount++;
				}
				bit <<= 1;
			}

			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//to ensure these are sign extended properly
					SystemModel.CPU.setAddrRegister(n, SystemModel.MEM.peek(start, size));
					start += 4;
					regcount++;
				}
				bit <<= 1;
			}
		}
		return regcount;
	}

	public static int putMultiplePreDec(int reglist, int address, Size size)
	{
		int bit = 1;
		int regcount = 0;
		int start = address;

		//assumes a7 is first bit
		for(int n = 0; n < 8; n++)
		{
			if((reglist & bit) != 0)
			{
				start -= size.byteSize();
				SystemModel.MEM.poke(start, SystemModel.CPU.getAddrRegister(7 - n), size);
				regcount++;
			}
			bit <<= 1;
		}

		for(int n = 0; n < 8; n++)
		{
			if((reglist & bit) != 0)
			{
				start -= size.byteSize();
				SystemModel.MEM.poke(start, SystemModel.CPU.getDataRegister(7 - n), size);
				regcount++;
			}
			bit <<= 1;
		}

		return regcount;
	}

	public static int getMultiplePreDec(int reglist, int address, Size size)
	{
		int bit = 1;
		int regcount = 0;
		int start = address;

		if(size == Size.Word)
		{
			//assumes a7 is first bit
			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//to ensure these are sign extended properly
					start -= 2;
					SystemModel.CPU.setAddrRegister(7 - n, (short)SystemModel.MEM.peek(start, size));
					regcount++;
				}
				bit <<= 1;
			}

			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//to ensure these are sign extended properly
					start -= 2;
					SystemModel.CPU.setDataRegister(7 - n, (short)SystemModel.MEM.peek(start, size));
					regcount++;
				}
				bit <<= 1;
			}
		}
		else
		{
			//assumes a7 is first bit
			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//to ensure these are sign extended properly
					start -= 4;
					SystemModel.CPU.setAddrRegister(7 - n, SystemModel.MEM.peek(start, size));
					regcount++;
				}
				bit <<= 1;
			}

			for(int n = 0; n < 8; n++)
			{
				if((reglist & bit) != 0)
				{
					//to ensure these are sign extended properly
					start -= 4;
					SystemModel.CPU.setDataRegister(7 - n, SystemModel.MEM.peek(start, size));
					regcount++;
				}
				bit <<= 1;
			}
		}
		return regcount;
	}
}
