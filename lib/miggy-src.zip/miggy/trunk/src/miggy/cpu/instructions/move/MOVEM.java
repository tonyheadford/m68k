package miggy.cpu.instructions.move;

import miggy.api.cpu.Size;
import miggy.api.cpu.DecodedInstruction;
import miggy.cpu.DecodedInstructionImpl;
import miggy.SystemModel;
import miggy.api.cpu.Operand;
import miggy.cpu.operands.OperandFactory;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class MOVEM
{
	private final int[] M2R_Timing = {
			0, 0, 12, 12, 0, 16, 18, 16, 20, 16, 18, 0, 0, 0, 0, 0
	};
	private final int[] R2M_Timing = {
			0, 0, 8, 0, 8, 12, 14, 12, 16, 0, 0, 0, 0, 0, 0, 0
	};

	public final int execute(int opcode, Size size)
	{
		int reglist = SystemModel.CPU.fetch(Size.Word);
		Operand mem;
		int time;
		int regcount;

		if((opcode & 0x0400) == 0)
		{
			// registers to memory
			mem = OperandFactory.fetchOperand((opcode & 0x0038) >> 3, (opcode & 0x007), false, size);
			time = R2M_Timing[mem.type().index()];
			regcount = mem.putMultiple(reglist, size);
		}
		else
		{
			// memory to registers
			mem = OperandFactory.fetchOperand((opcode & 0x0038) >> 3, (opcode & 0x007), true, size);
			time = M2R_Timing[mem.type().index()];
			regcount = mem.getMultiple(reglist, size);
		}

		if(size == Size.Long)
		{
			//multiply by 8
			time += (regcount << 3);
		}
		else
		{
			//multiply by 4
			time += (regcount << 2);
		}

		return time;
	}

	public final DecodedInstruction decode(int address, int opcode, Size size)
	{
		DecodedInstructionImpl di = new DecodedInstructionImpl("movem" + size.ext(), opcode, address, size);
		int list = SystemModel.MEM.peek(address + 2, Size.Word);

		if((opcode & 0x0400) == 0)
		{
			// registers to memory
			int mode = (opcode & 0x0038) >> 3;
			boolean predec = (mode == 4);

			di.setSrc(OperandFactory.regList(list, predec));
			di.setDst(OperandFactory.valueOf(address + 4, (opcode & 0x0038) >> 3, (opcode & 0x007), false, size));
		}
		else
		{
			// memory to registers
			di.setSrc(OperandFactory.valueOf(address + 4, (opcode & 0x0038) >> 3, (opcode & 0x007), true, size));
			di.setDst(OperandFactory.regList(list, false));
		}

		return di;
	}
}
