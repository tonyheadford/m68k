package miggy.cpu.instructions.or;

import miggy.api.cpu.DecodedInstruction;
import miggy.cpu.DecodedInstructionImpl;
import miggy.SystemModel;
import miggy.cpu.operands.OperandFactory;
import miggy.api.cpu.*;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class ORI
{
	public final int execute(int opcode, Size size)
	{
		int src = SystemModel.CPU.fetch(size);
		Operand dst = OperandFactory.fetchOperand((opcode & 0x0038) >> 3, (opcode & 0x007), false, size);

		if(dst.type() == EffectiveAddress.StatusReg)
		{
			//privileged instruction
			if(!SystemModel.CPU.isSupervisorMode())
			{
				//raise privilege violation exception
				SystemModel.CPU.raiseSRException();
				return 34;
			}
		}

		int result = src | dst.get(size);
		dst.put(result, size);

		//flags set directly if destination SR or CCR
		if(dst.type() != EffectiveAddress.StatusReg && dst.type() != EffectiveAddress.CCR)
		{
			if(result == 0)
			{
				SystemModel.CPU.setFlag(CpuFlag.Z);
				SystemModel.CPU.clrFlag(CpuFlag.N);
			}
			else
			{
				SystemModel.CPU.clrFlag(CpuFlag.Z);
				if((result & size.msb()) != 0)
				{
					SystemModel.CPU.setFlag(CpuFlag.N);
				}
				else
				{
					SystemModel.CPU.clrFlag(CpuFlag.N);
				}
			}
			SystemModel.CPU.clrFlag(CpuFlag.C);
			SystemModel.CPU.clrFlag(CpuFlag.V);
		}

		if(dst.isRegister())
		{
			return (size == Size.Long ? 16 : 8);
		}
		else
		{
			return (size == Size.Long ? 20 : 12) + dst.timing(size);
		}
	}

	public final DecodedInstruction decode(int address, int opcode, Size size)
	{
		DecodedInstructionImpl di = new DecodedInstructionImpl("ori" + size.ext(), opcode, address, size);
		//immediate src value
		//test: changed to peek
		di.setSrc(OperandFactory.immediate(SystemModel.MEM.peek(address + 2, ((size == Size.Byte) ? Size.Word : size)), size));
		di.setDst(OperandFactory.valueOf(address + 2 + di.src().offset(), (opcode & 0x0038) >> 3, (opcode & 0x007), false, size));
		return di;
	}
}
