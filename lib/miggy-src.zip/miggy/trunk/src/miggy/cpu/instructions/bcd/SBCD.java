package miggy.cpu.instructions.bcd;

import miggy.cpu.*;
import miggy.api.cpu.*;
import miggy.cpu.operands.OperandFactory;
import miggy.SystemModel;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class SBCD implements Instruction
{
	public final void register(InstructionSet set)
	{
		int base = 0x8100;
		for(int s = 0; s < 8; s++)
		{
			for(int d = 0; d < 8; d++)
			{
				set.add(base + (d << 9) + s, this);
			}
		}
 		base = 0x8108;
		for(int s = 0; s < 8; s++)
		{
			for(int d = 0; d < 8; d++)
			{
				set.add(base + (d << 9) + s, this);
			}
		}
	}

	public int execute(int opcode)
	{
		int time;
		int srcv;
		int dstv;
		int sreg = opcode & 0x0007;
		int dreg = (opcode & 0x0e00) >> 9;
		int result;
		Size size = Size.Byte;

		if((opcode & 8) != 0)
		{
			//addr reg format
			int saddr = SystemModel.CPU.getAddrRegister(sreg);
			int daddr = SystemModel.CPU.getAddrRegister(dreg);
			//a7 has special rules about keeping the address even - but assume we're not using a7
			saddr--;
			daddr--;
			SystemModel.CPU.setAddrRegister(sreg, saddr);
			SystemModel.CPU.setAddrRegister(dreg, daddr);

			//test: changed to peek
			srcv = (byte)SystemModel.MEM.peek(saddr, size);
			dstv = (byte)SystemModel.MEM.peek(daddr, size);

			result = doCalc(srcv, dstv);
			//test: changed to poke
			SystemModel.MEM.poke(daddr, result, size);
			time = 18;
		}
		else
		{
			//data reg format
			srcv = (byte)SystemModel.CPU.getDataRegister(sreg, size);
			dstv = (byte)SystemModel.CPU.getDataRegister(dreg, size);

			result = doCalc(srcv, dstv);
			SystemModel.CPU.setDataRegister(dreg, result, size);
			time = 6;
		}

		return time;
	}

	private static int doCalc(int srcv, int dstv)
	{
		int x = (SystemModel.CPU.isSet(CpuFlag.X) ? 1 : 0);
		int c;

		int lo = (dstv & 0x0f) - (srcv & 0x0f) - x;
		if(lo < 0)
		{
			lo += 10;
			c = 1;
		}
		else
		{
			c = 0;
		}

		int hi = ((dstv >> 4) & 0x0f) - ((srcv >> 4) & 0x0f) - c;
		if(hi < 0)
		{
			hi += 10;
			c = 1;
		}
		else
		{
			c = 0;
		}

		int result = (hi << 4) + lo;

		if(c != 0)
		{
			SystemModel.CPU.setFlag(CpuFlag.X);
			SystemModel.CPU.setFlag(CpuFlag.C);
		}
		else
		{
			SystemModel.CPU.clrFlag(CpuFlag.X);
			SystemModel.CPU.clrFlag(CpuFlag.C);
		}

		if(result != 0)
		{
			SystemModel.CPU.clrFlag(CpuFlag.Z);
		}

		return result;
	}

	public final DecodedInstruction disassemble(int address, int opcode)
	{
		Size size = Size.Byte;
		DecodedInstructionImpl di = new DecodedInstructionImpl("sbcd", opcode, address, size);
		if((opcode & 0x0008) == 0)
		{
			di.setSrc(OperandFactory.dataReg(opcode & 0x0007));
			di.setDst(OperandFactory.dataReg((opcode & 0x0e00) >> 9));
		}
		else
		{
			di.setSrc(OperandFactory.addrRegIndPreDec(opcode & 0x0007));
			di.setDst(OperandFactory.addrRegIndPreDec((opcode & 0x0e00) >> 9));
		}
		return di;
	}
}
