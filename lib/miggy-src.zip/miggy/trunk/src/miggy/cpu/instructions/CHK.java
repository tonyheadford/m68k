package miggy.cpu.instructions;

import miggy.cpu.*;
import miggy.cpu.operands.OperandFactory;
import miggy.SystemModel;
import miggy.api.cpu.*;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class CHK implements Instruction
{
	public final void register(InstructionSet set)
	{
		int base = 0x4180;
		for(int reg = 0; reg < 8; reg++)
		{
			for(int ea = 0; ea < 64; ea++)
			{
				set.add(base + (reg << 9) + ea, this);
			}
		}
	}

	public int execute(int opcode)
	{
		Operand src = OperandFactory.fetchOperand((opcode & 0x0038) >> 3, (opcode & 0x007), true, Size.Word);
		Operand dst = OperandFactory.dataReg((opcode & 0x0e00) >> 9);

		//src is effective address
		int srcVal = src.get(Size.Word);
		//dst is data register
		int dstVal = dst.get(Size.Word);

		if((dstVal & 0x8000) != 0)
		{
			//set N flag
			SystemModel.CPU.setFlag(CpuFlag.N);
			SystemModel.CPU.raiseException(6);	//CHK exception
			return 40 + src.timing(Size.Word);
		}
		else if(dstVal > srcVal)
		{
			//clr N flag
			SystemModel.CPU.clrFlag(CpuFlag.N);
			SystemModel.CPU.raiseException(6);	//CHK exception
			return 40 + src.timing(Size.Word);
		}
		else
		{
			return 10 + src.timing(Size.Word);
		}
	}

	public DecodedInstruction disassemble(int address, int opcode)
	{
		Size size = Size.Word;
		DecodedInstructionImpl di = new DecodedInstructionImpl("chk", opcode, address, size);
		di.setSrc(OperandFactory.valueOf(address + 2, (opcode & 0x0038) >> 3, (opcode & 0x007), true, size));
		di.setDst(OperandFactory.dataReg((opcode & 0x0e00) >> 9));
		return di;
	}
}
