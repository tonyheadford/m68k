package miggy.cpu.instructions.bcd;

import miggy.cpu.*;
import miggy.api.cpu.*;
import miggy.cpu.operands.OperandFactory;
import miggy.SystemModel;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class NBCD implements Instruction
{
	public final void register(InstructionSet set)
	{
		int base = 0x4800;
		for(int mode = 0; mode < 8; mode++)
		{
			if(mode == 1)
				continue;
			for(int reg = 0; reg < 8; reg++)
			{
				if(mode == 7 && reg > 1)
					break;

				set.add(base + (mode << 3) + reg, this);
			}
		}
	}

	public int execute(int opcode)
	{
		Operand src = OperandFactory.fetchOperand((opcode & 0x0038) >> 3, (opcode & 0x007), true, Size.Byte);
		int srcv = src.get(Size.Byte);

		int x = (SystemModel.CPU.isSet(CpuFlag.X) ? 1 : 0);
		int c;

		int lo = 10 - (srcv & 0x0f) - x;
		if(lo < 10)
		{
			c = 1;
		}
		else
		{
			lo = 0;
			c = 0;
		}

		int hi = 10 - ((srcv >> 4) & 0x0f) - c;
		if(hi < 10)
		{
			c = 1;
		}
		else
		{
			c = 0;
			hi = 0;
		}

		int result = (hi << 4) + lo;

		if(c != 0)
		{
			SystemModel.CPU.setFlag(CpuFlag.X);
			SystemModel.CPU.setFlag(CpuFlag.C);
		}
		else
		{
			SystemModel.CPU.clrFlag(CpuFlag.X);
			SystemModel.CPU.clrFlag(CpuFlag.C);
		}

		if(result != 0)
		{
			SystemModel.CPU.clrFlag(CpuFlag.Z);
		}

		src.put(result, Size.Byte);
		return (src.isRegister() ? 6 : 8);
	}

	public DecodedInstruction disassemble(int address, int opcode)
	{
		Size size = Size.Byte;
		DecodedInstructionImpl di = new DecodedInstructionImpl("nbcd", opcode, address, size);

		di.setSrc(OperandFactory.valueOf(address + 2, (opcode & 0x0038) >> 3, (opcode & 0x007), true, size));
		return di;
	}
}
