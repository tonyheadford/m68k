package miggy.cpu.instructions.dbcc;

import miggy.api.cpu.ConditionCode;
import miggy.api.cpu.Size;
import miggy.api.cpu.DecodedInstruction;
import miggy.cpu.DecodedInstructionImpl;
import miggy.SystemModel;
import miggy.cpu.operands.OperandFactory;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class DBxx
{
	public final int execute(int opcode, ConditionCode cc)
	{
		int time;

		Size size;
		int reg = opcode & 0x0007;
		int dval = (short)SystemModel.CPU.getDataRegister(reg, Size.Word);
		int pc = SystemModel.CPU.getPC();
		//signed displacement
		int displacement = (short)SystemModel.MEM.peek(pc, Size.Word);

		if(ConditionCode.test(cc))
		{
			//meets the condition exit loop - no branch
			SystemModel.CPU.setPC(pc + 2);
			time = 12;
		}
		else if(dval == 0)
		{
			//counter expired exit loop - no branch
			SystemModel.CPU.setPC(pc + 2);
			dval--;
			time = 14;
		}
		else
		{
			//condition false, counter not expired - branch
			SystemModel.CPU.setPC(pc + displacement);
			dval--;
			time = 10;
		}

		SystemModel.CPU.setDataRegister(reg, dval, Size.Word);
		return time;
	}

	public final DecodedInstruction decode(int address, int opcode, ConditionCode cc)
	{
		Size size = Size.Word;
		DecodedInstructionImpl di = new DecodedInstructionImpl("db" + cc, opcode, address, size);
		di.setSrc(OperandFactory.dataReg(opcode & 0x007));
		//test: changed to peek
		di.setDst(OperandFactory.immediate((short)SystemModel.MEM.peek(address + 2, size), size));
		return di;
	}
}
