package miggy.cpu.instructions.bcc;

import miggy.cpu.*;
import miggy.cpu.operands.OperandFactory;
import miggy.SystemModel;
import miggy.api.cpu.ConditionCode;
import miggy.api.cpu.Size;
import miggy.api.cpu.DecodedInstruction;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/

public class Bxx
{
	public final int execute(int opcode, ConditionCode cc)
	{
		int time;

		Size size;
		int displacement = (byte)(opcode & 0x00ff);
		int pc = SystemModel.CPU.getPC();

		if(displacement == 0)
		{
			size = Size.Word;
			//sign extend displacement
			displacement = (short)SystemModel.MEM.peek(pc, size);
		}
		else
		{
			size = Size.Byte;
		}

		if(cc == ConditionCode.F)
		{
			// bsr
			if(size == Size.Word)
				SystemModel.CPU.push(pc + 2, Size.Long);
			else
				SystemModel.CPU.push(pc, Size.Long);

			SystemModel.CPU.setPC(pc + displacement);
			time = 18;
		}
		else if(ConditionCode.test(cc))
		{
			//meets the condition so branch
			SystemModel.CPU.setPC(pc + displacement);
			time = 10;
		}
		else
		{
			//didn't meet condition
			if(size == Size.Byte)
			{
				time = 8;
			}
			else
			{
				time = 12;
				//catch up word displacement
				SystemModel.CPU.setPC(pc + 2);
			}
		}

		return time;
	}

	public final DecodedInstruction decode(int address, int opcode, ConditionCode cc)
	{
		Size size;
		String ext;
		int displacement = (byte)(opcode & 0x00FF);

		if(displacement == 0)
		{
			size = Size.Word;
			ext = ".w";
			//signed displacement
			displacement = (short)SystemModel.MEM.peek(address + 2, Size.Word);
		}
		else
		{
			size = Size.Byte;
			ext = ".s";
		}
		String name;
		//special case for BRA and BSR
		if(cc == ConditionCode.T) //000
		{
			name = "bra";
		}
		else if(cc == ConditionCode.F)	//001
		{
			name = "bsr";
		}
		else
		{
			name = "b" + cc;
		}

		DecodedInstructionImpl di = new DecodedInstructionImpl(name + ext, opcode, address, size);
		di.setSrc(OperandFactory.displacement(displacement, size));

		return di;
	}
}
