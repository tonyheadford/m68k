package miggy.cpu.instructions.move;

import miggy.api.cpu.Size;
import miggy.api.cpu.DecodedInstruction;
import miggy.cpu.DecodedInstructionImpl;
import miggy.SystemModel;
import miggy.api.cpu.Operand;
import miggy.api.cpu.CpuFlag;
import miggy.cpu.operands.OperandFactory;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class MOVE
{
	protected static final int[] ShortExecutionTime = {
		 4,  4,  8,  8,  8, 12, 14, 12, 16, 0, 0, 0, 0, 0, 0, 0,
		 4,  4,  8,  8,  8, 12, 14, 12, 16, 0, 0, 0, 0, 0, 0, 0,
		 8,  8, 12, 12, 12, 16, 18, 16, 20, 0, 0, 0, 0, 0, 0, 0,
		 8,  8, 12, 12, 12, 16, 18, 16, 20, 0, 0, 0, 0, 0, 0, 0,
		10, 10, 14, 14, 14, 18, 20, 18, 22, 0, 0, 0, 0, 0, 0, 0,
		12, 12, 16, 16, 16, 20, 22, 20, 24, 0, 0, 0, 0, 0, 0, 0,
		14, 14, 18, 18, 18, 22, 24, 22, 26, 0, 0, 0, 0, 0, 0, 0,
		12, 12, 16, 16, 16, 20, 22, 20, 24, 0, 0, 0, 0, 0, 0, 0,
		16, 16, 20, 20, 20, 24, 26, 24, 28, 0, 0, 0, 0, 0, 0, 0,
		12, 12, 16, 16, 16, 20, 22, 20, 24, 0, 0, 0, 0, 0, 0, 0,
		14, 14, 18, 18, 18, 22, 24, 22, 26, 0, 0, 0, 0, 0, 0, 0,
		 8,  8, 12, 12, 12, 16, 18, 16, 20, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0 };

	protected static final int[] LongExecutionTime = {
		 4,  4, 12, 12, 12, 16, 18, 16, 20, 0, 0, 0, 0, 0, 0, 0,
		 4,  4, 12, 12, 12, 16, 18, 16, 20, 0, 0, 0, 0, 0, 0, 0,
		12, 12, 20, 20, 20, 24, 26, 24, 28, 0, 0, 0, 0, 0, 0, 0,
		12, 12, 20, 20, 20, 24, 26, 24, 28, 0, 0, 0, 0, 0, 0, 0,
		14, 14, 22, 22, 22, 26, 28, 26, 30, 0, 0, 0, 0, 0, 0, 0,
		16, 16, 24, 24, 24, 28, 30, 28, 32, 0, 0, 0, 0, 0, 0, 0,
		18, 18, 26, 26, 26, 30, 32, 30, 34, 0, 0, 0, 0, 0, 0, 0,
		16, 16, 24, 24, 24, 28, 30, 28, 32, 0, 0, 0, 0, 0, 0, 0,
		20, 20, 28, 28, 28, 32, 34, 32, 36, 0, 0, 0, 0, 0, 0, 0,
		16, 16, 24, 24, 24, 28, 30, 28, 32, 0, 0, 0, 0, 0, 0, 0,
		18, 18, 26, 26, 26, 30, 32, 30, 34, 0, 0, 0, 0, 0, 0, 0,
		12, 12, 20, 20, 20, 24, 26, 24, 28, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0,
		 0,  0,  0,  0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0 };


	protected final int execute(int opcode, Size size)
	{
		Operand src = OperandFactory.fetchOperand((opcode & 0x0038) >> 3, (opcode & 0x007), true, size);
		Operand dst = OperandFactory.fetchOperand((opcode & 0x01c0) >> 6, (opcode & 0x0e00) >> 9, false, size);

		int srcv = src.get(size);
		dst.put(srcv, size);

		SystemModel.CPU.clrFlag(CpuFlag.C);
		SystemModel.CPU.clrFlag(CpuFlag.V);

		if(srcv == 0)
		{
			SystemModel.CPU.setFlag(CpuFlag.Z);
			SystemModel.CPU.clrFlag(CpuFlag.N);
		}
		else
		{
			SystemModel.CPU.clrFlag(CpuFlag.Z);

			if((srcv & size.msb()) != 0)
			{
				SystemModel.CPU.setFlag(CpuFlag.N);
			}
			else
			{
				SystemModel.CPU.clrFlag(CpuFlag.N);
			}
		}

		int time;
		int idx = (src.type().index() << 4) + dst.type().index();
		if(size == Size.Long)
		{
			time = LongExecutionTime[idx];
		}
		else
		{
			time = ShortExecutionTime[idx];
		}
		return time;
	}

	protected final DecodedInstruction decode(int address, int opcode, Size size)
	{
		String name;
		if((opcode & 0x01c0) == 0x0040)
			name = "movea";
		else
			name = "move";

		DecodedInstructionImpl di = new DecodedInstructionImpl(name + size.ext(), opcode, address, size);

		di.setSrc(OperandFactory.valueOf(address + 2, (opcode & 0x0038) >> 3, (opcode & 0x007), true, size));
		di.setDst(OperandFactory.valueOf(address + 2 + di.src().offset(), (opcode & 0x01c0) >> 6, (opcode & 0x0e00) >> 9, false, size));
		return di;
	}
}
