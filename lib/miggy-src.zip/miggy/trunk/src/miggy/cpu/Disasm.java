package miggy.cpu;

import miggy.SystemModel;
import miggy.utils.TextUtil;

import java.io.File;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class Disasm
{
	public static void main(String[] args)
	{
		if(args.length == 0 || args[0].equalsIgnoreCase("--help"))
		{
			usage();
			return;
		}

		int base = 0;
		int offset = 0;
		String file = null;

		for(int n = 0; n < args.length; n++)
		{
			String a = args[n];

			if(a.equals("-b") || a.equals("--base"))
			{
				if(n < (args.length - 1))
				{
					try
					{
						if(args[n+1].startsWith("0x"))
						{
							base = Integer.parseInt(args[n+1].substring(2), 16);
						}
						else
						{
							base = Integer.parseInt(args[n+1]);
						}
						n++;
					}
					catch(Exception e)
					{
						System.out.println("Invalid number for param " + args[n]);
						usage();
						return;
					}
				}
				else
				{
					System.out.println("--org with no address ");
					usage();
					return;
				}
			}
			else if(a.equals("-o") || a.equals("--offset"))
			{
				if(n < (args.length - 1))
				{
					try
					{
						if(args[n+1].startsWith("0x"))
						{
							offset = Integer.parseInt(args[n+1].substring(2), 16);
						}
						else
						{
							offset = Integer.parseInt(args[n+1]);
						}
						n++;
					}
					catch(Exception e)
					{
						System.out.println("Invalid number for param " + args[n]);
						usage();
						return;
					}
				}
				else
				{
					System.out.println(args[n] + " with no value");
					usage();
					return;
				}
			}
			else
			{
				file = a;
				break;
			}
		}

		if(file == null)
		{
			usage();
			return;
		}

		File f = new File(file);
		if(!f.exists())
		{
			System.out.println("Error: Cannot find input file [" + file + "]");
			return;
		}

		SystemModel.CPU = new MC68000();
//TODO: Fixme		SystemModel.CPU.init();

		//SystemModel.MEM = FileMem.create(f, base);

		banner(true);
		System.out.println("; File: " + f.getAbsolutePath() + " (" + f.length() +" bytes)");
		System.out.println("; Base: " + TextUtil.toHex(base) + "    Offset: " + TextUtil.toHex(offset) + "\n");

		Disassembler d = new StdOutDisassembler();

		int addr = base + offset;
		long length = f.length() + base;
		try
		{
			while(addr < length)
			{
				addr = d.disassemble(addr);
			}
		}
		catch(IndexOutOfBoundsException e)
		{
			e.printStackTrace();
		}
	}

	public static void banner(boolean comment)
	{
		if(!comment)
			System.out.println("");

		if(comment)
			System.out.print("; ");

		System.out.println("Miggy - Java Amiga Emulator - Copyright (C) 2008, Tony Headford");

		if(comment)
			System.out.print("; ");

		System.out.println("Disassembler v0.1");
	}

	public static void usage()
	{
		banner(false);
		System.out.println("\nUsage: Disasm [-b|--base value][-o|--offset value] filename\n");
	}
}
