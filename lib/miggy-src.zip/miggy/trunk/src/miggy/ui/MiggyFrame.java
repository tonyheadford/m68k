package miggy.ui;

import miggy.api.machine.MachineCore;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.Logger;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public final class MiggyFrame extends JFrame implements ActionListener
{
	private static Logger logger = Logger.getLogger(MiggyFrame.class.getName());
	private final MachineCore emu;
	private JPanel display;

	public MiggyFrame(MachineCore emu, String title)
	{
		super(title);
		this.emu = emu;
		create();
	}

	private void create()
	{
		buildMenu();

		display = new JPanel(true);
		Dimension d = new Dimension(320,256);
		display.setPreferredSize(d);
		display.setMinimumSize(d);
		display.setMaximumSize(d);
		display.setBackground(Color.BLACK);
		add(display, BorderLayout.CENTER);
		pack();
	}

	private void buildMenu()
	{
		JMenuBar menuBar = new JMenuBar();

		//File Menu
		JMenu menu = new JMenu("File");
		menu.setMnemonic(KeyEvent.VK_F);
		menuBar.add(menu);

		//Open
		JMenuItem item = new JMenuItem("Open", KeyEvent.VK_O);
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
		item.addActionListener(this);
		menu.add(item);

		//Close
		item = new JMenuItem("Close", KeyEvent.VK_C);
		//item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
		item.addActionListener(this);
		menu.add(item);

		menu.addSeparator();

		//Exit
		item = new JMenuItem("Exit", KeyEvent.VK_X);
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.ALT_MASK));
		item.addActionListener(this);
		menu.add(item);


		//Run Menu
		menu = new JMenu("Run");
		menu.setMnemonic(KeyEvent.VK_R);
		menuBar.add(menu);

		//Run
		item = new JMenuItem("Start", KeyEvent.VK_S);
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
		item.addActionListener(this);
		menu.add(item);

		//Stop
		item = new JMenuItem("Stop", KeyEvent.VK_T);
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, 0));
		item.addActionListener(this);
		menu.add(item);

		menu.addSeparator();

		//Debugger
		item = new JMenuItem("Debugger", KeyEvent.VK_D);
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F6, 0));
		item.addActionListener(this);
		menu.add(item);

		setJMenuBar(menuBar);
	}

	/**
	 * Invoked when an action occurs.
	 */
	public final void actionPerformed(ActionEvent e)
	{
		//To change body of implemented methods use File | Settings | File Templates.
		logger.info("ActionEvent: " + e.getActionCommand());
		if(e.getActionCommand().equalsIgnoreCase("Start"))
		{
			logger.info("Starting Emu");
			emu.start();
		}
		else if(e.getActionCommand().equalsIgnoreCase("Stop"))
		{
			logger.info("Stopping Emu");
			emu.stop();
		}
		else if(e.getActionCommand().equalsIgnoreCase("Debugger"))
		{
			logger.info("Debugger");
			emu.debug(!emu.isDebugging());
		}
		else if(e.getActionCommand().equalsIgnoreCase("Exit"))
		{
			logger.info("Exiting from menu");
		}
	}
}
