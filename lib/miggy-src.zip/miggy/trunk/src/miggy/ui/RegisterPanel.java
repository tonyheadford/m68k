package miggy.ui;

import miggy.Debugger;

import javax.swing.*;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.logging.Logger;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public final class RegisterPanel extends JPanel
{
	private static Logger logger = Logger.getLogger(RegisterPanel.class.getName());
	private final Debugger debugger;
	private final RegisterModel model;
	private final JTable table;
	private final int borderWidth = 2;

	public RegisterPanel(Debugger debugger)
	{
		super(new BorderLayout());
		logger.info("Constructing RegisterPanel");

		this.debugger = debugger;
		setMinimumSize(new Dimension(300, 200));

		model = new RegisterModel();
		table = new JTable(model);

		Font listFont = new Font("Courier New", Font.PLAIN, 13);
		table.setFont(listFont);
		table.setShowGrid(false);
		FontMetrics metrics = table.getFontMetrics(listFont);

		//fixed width should all be the same
		int[] sizes = metrics.getWidths();

		TableColumn col;
		for(int n = 0; n < model.getColumnCount(); n++)
		{
			col = table.getColumnModel().getColumn(n);
			if(n == 0 || n == 3)
			{
				col.setPreferredWidth(sizes['0'] * 6);
			}
			else if(n == 1 || n == 2 || n == 4)
			{
				col.setPreferredWidth(sizes['0'] * 10);
			}
			else
			{
				col.setPreferredWidth(sizes['0'] * 40);
			}
		}
		table.setSelectionBackground(table.getBackground());
		table.setSelectionForeground(table.getForeground());
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		add(table, BorderLayout.CENTER);
	}

	public final void updateData()
	{
		model.updateAll();

		//crazy but this all needs to be set up again here when window is
		//hidden/shown
		FontMetrics metrics = table.getFontMetrics(table.getFont());

		//fixed width should all be the same ?
		int[] sizes = metrics.getWidths();

		TableColumn col;
		for(int n = 0; n < model.getColumnCount(); n++)
		{
			col = table.getColumnModel().getColumn(n);
			if(n == 0 || n == 3)
			{
				col.setPreferredWidth(sizes['0'] * 6);
			}
			else if(n == 1 || n == 2 || n == 4)
			{
				col.setPreferredWidth(sizes['0'] * 10);
			}
			else
			{
				col.setPreferredWidth(sizes['0'] * 40);
			}
		}
	}
}
