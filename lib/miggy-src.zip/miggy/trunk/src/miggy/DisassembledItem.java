package miggy;

import miggy.utils.TextUtil;
import miggy.api.cpu.DecodedInstruction;
import miggy.api.cpu.Operand;
import miggy.api.cpu.Size;
import miggy.cpu.operands.OperandFactory;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public final class DisassembledItem
{
	private final int address;
	private final int size;
	private final String instruction;
	private final String bytes;
	private final String itemText;

	public static final DisassembledItem EmptyItem = new DisassembledItem();

	public DisassembledItem(int address, String instruction, String bytes, int size)
	{
		this.address = address;
		this.instruction = instruction;
		this.bytes = bytes;
		this.size = size;

		StringBuilder sb = new StringBuilder();
		sb.append(TextUtil.toHex(address));
		sb.append("    ");
		sb.append(TextUtil.pad(instruction, 34));
		sb.append(bytes);
		itemText = sb.toString();
	}

	private DisassembledItem()
	{
		//constructor for the special EmptyItem
		this.address = 0x00ffffff;	//max
		this.instruction = "";
		this.bytes = "";
		this.size = 0;
		itemText = "????????    ????";
	}

	public final int getAddress()
	{
		return address;
	}

	public final String getInstruction()
	{
		return instruction;
	}

	public final String getBytes()
	{
		return bytes;
	}

	public final int getSize()
	{
		return size;
	}

	@Override
	public String toString()
	{
		return itemText;
	}

	public static DisassembledItem makeDisassembledItem(DecodedInstruction di)
	{
		//make a DisassembledItem
		StringBuilder mem = new StringBuilder();
		Operand src = di.src();
		Operand dst = di.dst();

		int bytes = src.offset() + dst.offset();
		mem.append(TextUtil.toHex((short)di.opcode()));
		for(int n = 0; n < bytes; n+=2)
		{
			mem.append(" ");
			mem.append(TextUtil.toHex((short)SystemModel.MEM.directPeek(di.address() + 2 + n, Size.Word)));
		}

		StringBuilder sb = new StringBuilder();
		sb.append(TextUtil.pad(di.name(), 9));

		if(src != OperandFactory.UnusedOperand())
		{
			sb.append(src);
		}
		if(dst != OperandFactory.UnusedOperand())
		{
			//requires that single param instructions use src not dst
			sb.append(",");
			sb.append(dst);
		}

		int size = src.offset() + dst.offset() + 2;

		return new DisassembledItem(di.address(), sb.toString(), mem.toString(), size);
	}
}
