package miggy;

import miggy.config.SystemDefinition;
import miggy.machine.Miggy;

import javax.swing.*;
import java.util.logging.Level;
import java.util.logging.Logger;

// $Revision: 21 $
public class MiggyLauncher
{
	private static Logger logger = Logger.getLogger("Miggy.Launcher");

	public static void main(String[] args)
	{
		//get the system definition
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

			String cfgFile;
			if(args.length > 0)
				cfgFile = args[0];
			else
				cfgFile = "default.miggy";

			SystemDefinition config = SystemDefinition.load(cfgFile);

			new Miggy().boot(config);
		}
		catch(Throwable t)
		{
			t.printStackTrace();
			logger.log(Level.SEVERE, "Halting due to error", t);
		}
	}
}
