package miggy;

import miggy.api.config.MachineDefinition;
import miggy.api.cpu.MC680x0;
import miggy.api.display.DisplayController;
import miggy.api.dma.DMAController;
import miggy.api.memory.AddressSpace;
import miggy.api.memory.CustomRegisterController;
import miggy.api.machine.MachineCore;
import miggy.hardware.CIA8520;
import miggy.hardware.CIAA;
import miggy.hardware.CIAB;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class SystemModel
{
	public static MachineCore EMU = null;
	public static MC680x0 CPU = null;
	public static AddressSpace MEM = null;
	public static CustomRegisterController REGS = null;
	public static DisplayController DISPLAY = null;
	public static DMAController DMA = null;
	public static CIA8520 CIAA = null;
	public static CIA8520 CIAB = null;
	public static MachineDefinition CFG = null;

	public static void buildModel(MachineCore emu, MachineDefinition config) throws Exception
	{
		SystemModel.EMU = emu;
		SystemModel.CFG = config;

		//load the classes
		Class c = Class.forName(config.getRegisterControllerName());
		CustomRegisterController regs = (CustomRegisterController)c.newInstance();

		c = Class.forName(config.getMemoryControllerName());
		AddressSpace mem = (AddressSpace)c.newInstance();

		c = Class.forName(config.getCpuName());
		MC680x0 cpu = (MC680x0)c.newInstance();

		c = Class.forName(config.getDmaControllerName());
		DMAController dma = (DMAController)c.newInstance();

		c = Class.forName(config.getDisplayControllerName());
		DisplayController display = (DisplayController)c.newInstance();

		SystemModel.CPU = cpu;
		SystemModel.REGS = regs;
		SystemModel.MEM = mem;
		SystemModel.DISPLAY = display;
		SystemModel.DMA = dma;

		SystemModel.CIAA = new CIAA();
		SystemModel.CIAB = new CIAB();

		//initialise the system
		regs.init(config);
		mem.init(config);
		cpu.init(config);
		display.init(config);
		dma.init(config);

		//call after mem in place
		reset();
	}

	/**
	 * Called to reset the system components to their power on state
	 * This will be called from the RESET CPU instruction
	 */
	public static void reset()
	{
		//todo: add others here as they're added to the system

		MEM.reset();
		//CPU has to happen after MEM
		CPU.reset();
		DMA.reset();
		DISPLAY.reset();
	}
}
