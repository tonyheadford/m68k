package miggy.utils;

import miggy.api.cpu.Size;
import miggy.api.cpu.MC680x0;
import miggy.SystemModel;

/*
//  Miggy - Java Amiga MachineCore
//  Copyright (c) 2008, Tony Headford
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
//  following conditions are met:
//
//    o  Redistributions of source code must retain the above copyright notice, this list of conditions and the
//       following disclaimer.
//    o  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
//       following disclaimer in the documentation and/or other materials provided with the distribution.
//    o  Neither the name of the Miggy Project nor the names of its contributors may be used to endorse or promote
//       products derived from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
//  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
//  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
//  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
//  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// $Revision: 21 $
*/
public class TextUtil
{
	static final char[] HEX = "0123456789ABCDEF".toCharArray();

	public static String toHex(byte b)
	{
		StringBuffer sb = new StringBuffer(4);
		sb.append(HEX[(b & 0xF0) >> 4]);
		sb.append(HEX[(b & 0x0F)]);
		return sb.toString();
	}

	public static String toHex(short s)
	{
		StringBuffer b = new StringBuffer(4);
		b.append(HEX[(s & 0xF000) >> 12]);
		b.append(HEX[(s & 0x0F00) >> 8]);
		b.append(HEX[(s & 0x00F0) >> 4]);
		b.append(HEX[(s & 0x000F)]);
		return b.toString();
	}

	public static String toHex(int i)
	{
		StringBuffer b = new StringBuffer(8);
		b.append(HEX[((i & 0xF0000000) >> 28) & 0x0F]);
		b.append(HEX[(i & 0x0F000000) >> 24]);
		b.append(HEX[(i & 0x00F00000) >> 20]);
		b.append(HEX[(i & 0x000F0000) >> 16]);
		b.append(HEX[(i & 0xF000) >> 12]);
		b.append(HEX[(i & 0x0F00) >> 8]);
		b.append(HEX[(i & 0x00F0) >> 4]);
		b.append(HEX[(i & 0x000F)]);
		return b.toString();
	}

	public static String toHexNoLeadingZero(int i)
	{
		StringBuffer b = new StringBuffer(8);
		int shift = 28;
		boolean started = false;

		for(int n = 0; n < 8; n++, shift -= 4)
		{
			int nibble = (i >>> shift) & 0x0f;

			if(!started)
			{
				if(nibble != 0)
					started = true;
				else
					continue;
			}
			b.append(HEX[nibble]);
		}
		return b.toString();
	}


	public static String toHex(int value, Size size)
	{
		switch(size)
		{
			case Byte:
				return toHex((byte)value);
			case Word:
				return toHex((short)value);
			case Long:
				return toHex(value);
		}

		throw new RuntimeException("Somehow size wasn't one of the enum values");
	}

	public static String toHexSigned(int value, Size size)
	{
		StringBuilder b = new StringBuilder(9);
		boolean neg;

		switch(size)
		{
			case Byte:
				neg = (value & 0x80) != 0;
				break;
			case Word:
				neg = (value & 0x8000) != 0;
				break;
			case Long:
				neg = (value & 0x80000000) != 0;
				break;
			default:
				throw new IllegalArgumentException("Unknown size: " + size);
		}

		if(neg)
		{
			value = ((~value) + 1) & size.mask();
			b.append('-');
		}

		switch(size)
		{
			case Byte:
			{
				b.append(toHex((byte)value));
				break;
			}
			case Word:
			{
				b.append(toHex((short)value));
				break;
			}
			case Long:
			{
				b.append(toHex(value));
				break;
			}
			default:
				throw new RuntimeException("Somehow size wasn't one of the enum values");
		}
		return b.toString();
	}



	public static String toHexParam(int value, Size size, boolean signed)
	{
		if(value == 0)	//quick out
			return "0";

		StringBuilder b = new StringBuilder(9);
		boolean neg;

		if(signed)
		{
			switch(size)
			{
				case Byte:
					neg = (value & 0x80) != 0;
					break;
				case Word:
					neg = (value & 0x8000) != 0;
					break;
				case Long:
					neg = (value & 0x80000000) != 0;
					break;
				default:
					throw new IllegalArgumentException("Unknown size: " + size);
			}

			if(neg)
			{
				value = ((~value) + 1) & size.mask();
				b.append('-');
			}
		}

		boolean started = false;
		int mask = 0xf0000000;
		int shift = 28;
		for(int n = 0; n < 8; n++)
		{
			if((value & mask) != 0)
			{
				started = true;
			}
			if(started)
			{
				b.append(HEX[((value & mask) >> shift) & 0x0F]);
			}
			shift -= 4;
			mask >>= 4;
		}
		return b.toString();
	}


	public static String pad(String s, int length)
	{
		StringBuilder sb = new StringBuilder(length);

		int count = length - s.length();
		if(count > 0)
		{
			sb.append(s);
			for(int i = 0; i < count; i++)
			{
				sb.append(' ');
			}
		}
		else
		{
			sb.append(s.substring(0, length - 1));
		}

		return sb.toString();
	}

	public static String decodeRegList(int list, boolean reverse)
	{
		StringBuilder sb = new StringBuilder();
		int first = -1;
		int count = 0;

		if(!reverse)
		{
			//normal mode lsb = d0
			char prefix = 'd';
			int mask = 1;

			for(int i = 0; i < 2; i++)
			{
				for(int n = 0; n < 8; n++, mask <<= 1)
				{
					if((list & mask) != 0)
					{
						if(first != -1)
						{
							count++;
						}
						else
						{
							first = n;
						}
					}
					else
					{
						if(first != -1)
						{
							if(sb.length() > 0)
								sb.append('/');

							sb.append(prefix);
							sb.append(first);
							if(count == 1)
							{
								sb.append('/');
								sb.append(prefix);
								sb.append(n - 1);
							}
							else if(count > 1)
							{
								sb.append('-');
								sb.append(prefix);
								sb.append(n - 1);
							}

							count = 0;
							first = -1;
						}
					}
				}

				if(first != -1)
				{
					if(sb.length() > 0)
						sb.append('/');

					sb.append(prefix);
					sb.append(first);
					if(count == 1)
					{
						sb.append('/');
						sb.append(prefix);
						sb.append(7);
					}
					else if(count > 1)
					{
						sb.append('-');
						sb.append(prefix);
						sb.append(7);
					}

					count = 0;
					first = -1;
				}

				prefix = 'a';
			}
		}
		else
		{
			//reverse mode for -(an) lsb = a7
			//normal mode lsb = d0
			char prefix = 'd';
			int mask = 0x8000;

			for(int i = 0; i < 2; i++)
			{
				for(int n = 0; n < 8; n++, mask >>= 1)
				{
					if((list & mask) != 0)
					{
						if(first != -1)
						{
							count++;
						}
						else
						{
							first = n;
						}
					}
					else
					{
						if(first != -1)
						{
							if(sb.length() > 0)
								sb.append('/');

							sb.append(prefix);
							sb.append(first);
							if(count == 1)
							{
								sb.append('/');
								sb.append(prefix);
								sb.append(n - 1);
							}
							else if(count > 1)
							{
								sb.append('-');
								sb.append(prefix);
								sb.append(n - 1);
							}

							count = 0;
							first = -1;
						}
					}
				}

				if(first != -1)
				{
					if(sb.length() > 0)
						sb.append('/');

					sb.append(prefix);
					sb.append(first);
					if(count == 1)
					{
						sb.append('/');
						sb.append(prefix);
						sb.append(7);
					}
					else if(count > 1)
					{
						sb.append('-');
						sb.append(prefix);
						sb.append(7);
					}

					count = 0;
					first = -1;
				}

				prefix = 'a';
			}
		}

		return sb.toString();
	}



	public static String getSRFlags()
	{
		int sr = SystemModel.CPU.getSR();

		StringBuilder sb = new StringBuilder(8);

		if((sr & MC680x0.TRACE_FLAG) != 0)
			sb.append('T');
		else
			sb.append(' ');

		if((sr & MC680x0.SUPER_FLAG) != 0)
			sb.append('S');
		else
			sb.append(' ');

		if((sr & MC680x0.X_FLAG) != 0)
			sb.append('X');
		else
			sb.append(' ');

		if((sr & MC680x0.N_FLAG) != 0)
			sb.append('N');
		else
			sb.append(' ');

		if((sr & MC680x0.Z_FLAG) != 0)
			sb.append('Z');
		else
			sb.append(' ');

		if((sr & MC680x0.V_FLAG) != 0)
			sb.append('V');
		else
			sb.append(' ');

		if((sr & MC680x0.C_FLAG) != 0)
			sb.append('C');
		else
			sb.append(' ');

		return sb.toString();
	}

	public static String makeMemView(int address)
	{
		//make a view of the 8 bytes of memory starting at address
		StringBuilder s1 = new StringBuilder();
		StringBuilder s2 = new StringBuilder();
		int top;

		if(address + 7 > 0x00ffffff)
		{
			//we go out of bounds
			top = 0x01000000;
		}
		else
		{
			top = address + 8;
		}

		int count = 0;
		for(int a = address; a < top; a++)
		{
			byte b = (byte)SystemModel.MEM.directPeek(a, Size.Byte);
			s1.append(HEX[(b & 0xF0) >> 4]);
			s1.append(HEX[(b & 0x0F)]);
			s1.append(' ');

			if(b > 31 && b < 127)
				s2.append((char)b);
			else
				s2.append('.');

			count++;
		}

		for(; count < 8; count++)
		{
			s1.append("??");
			s1.append(' ');
			s2.append('?');
		}

		s1.append(' ');
		s1.append(s2);
		return s1.toString();
	}

	public static String toAscii(int value)
	{
		//for register panel view of data registers
		StringBuilder sb = new StringBuilder();
		int shift = 24;
		for(int n = 0; n < 4; n++)
		{
			byte b = (byte)((value >>> shift) & 0x00ff);
			if(b > 31 && b < 127)
				sb.append((char)b);
			else
				sb.append('.');

			shift -= 8;
		}

		return sb.toString();
	}
}
