#!/bin/sh

java -cp miggy.jar miggy.cpu.Disasm $1 $2 $3 $4 $5
