package miggy.cpu.instructions.or;

import miggy.BasicSetup;
import miggy.SystemModel;
import miggy.api.cpu.CpuFlag;

// $Revision: 21 $
public class ORITest extends BasicSetup
{
	public ORITest(String test)
	{
		super(test);
	}

	public void testByte()
	{
		setInstructionParamW(0x0000, 0x0078);	//ori.b #$78, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x87654379, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testWord()
	{
		setInstructionParamW(0x0040, 0xaa78);	//ori.w #$aa78, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x8765eb79, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testLong()
	{
		setInstructionParamL(0x0080, 0x12345678);	//eori.l #$12345678, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x97755779, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}
}
