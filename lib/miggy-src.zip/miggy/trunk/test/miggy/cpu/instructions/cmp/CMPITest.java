package miggy.cpu.instructions.cmp;

import miggy.BasicSetup;
import miggy.SystemModel;
import miggy.api.cpu.CpuFlag;
import miggy.api.cpu.Size;

// $Revision: 21 $
public class CMPITest extends BasicSetup
{
	public CMPITest(String test)
	{
		super(test);
	}

	public void testByte()
	{
		setInstructionParamW(0x0c00, 0x00e8);	//cmpi.b #e8, d0
		SystemModel.CPU.setDataRegister(0, 0x876543e8);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertTrue("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testWord()
	{
		setInstructionParamW(0x0c40, 0x8321);	//cmpi.w #$8321, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertTrue("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertTrue("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testLong()
	{
		setInstructionParamL(0x0c80, 0xcc00cc00);	//cmpi.l #$cc00cc00, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertTrue("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testMem()
	{
		setInstructionParamW(0x0c50, 0x8765);	//cmpi #$8765,(a0)
		SystemModel.CPU.setAddrRegister(0, 32);
		SystemModel.MEM.poke(32, 0x87654321, Size.Long);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertTrue("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}
}
