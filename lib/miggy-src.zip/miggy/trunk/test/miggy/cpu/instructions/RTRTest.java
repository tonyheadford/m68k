package miggy.cpu.instructions;

import miggy.BasicSetup;
import miggy.SystemModel;
import miggy.api.cpu.CpuFlag;
import miggy.api.cpu.Size;

// $Revision: 21 $
public class RTRTest extends BasicSetup
{
	public RTRTest(String test)
	{
		super(test);
	}

	public void testReturn()
	{
		setInstruction(0x4e77);	//rtr

		SystemModel.CPU.setCCR((byte)0);
		SystemModel.CPU.push(codebase + 100, Size.Long);
		SystemModel.CPU.push(0x341f, Size.Word);

		int time = SystemModel.CPU.execute();

		assertEquals("Check PC restored", codebase + 100, SystemModel.CPU.getPC());
		assertEquals("Check CCR restored, SR unaffected", 0x001f, SystemModel.CPU.getSR());
		assertTrue("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertTrue("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertTrue("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertTrue("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}
}
