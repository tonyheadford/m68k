package miggy.cpu.instructions.neg;

import miggy.BasicSetup;
import miggy.SystemModel;
import miggy.api.cpu.CpuFlag;

// $Revision: 21 $
public class NEGTest extends BasicSetup
{
	public NEGTest(String test)
	{
		super(test);
	}

	public void testByte()
	{
		setInstruction(0x4400);	//neg.b d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x876543df, SystemModel.CPU.getDataRegister(0));
		assertTrue("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertTrue("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testWord()
	{
		setInstruction(0x4440);	//neg.w d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x8765bcdf, SystemModel.CPU.getDataRegister(0));
		assertTrue("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertTrue("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testLong()
	{
		setInstruction(0x4480);	//neg.l d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x789abcdf, SystemModel.CPU.getDataRegister(0));
		assertTrue("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertTrue("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}
}

