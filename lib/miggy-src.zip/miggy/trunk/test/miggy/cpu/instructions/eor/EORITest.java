package miggy.cpu.instructions.eor;

import miggy.BasicSetup;
import miggy.SystemModel;
import miggy.api.cpu.CpuFlag;
import miggy.api.cpu.Size;

// $Revision: 21 $
public class EORITest extends BasicSetup
{
	public EORITest(String test)
	{
		super(test);
	}

	public void testByte()
	{
		setInstructionParamW(0x0a00, 0x0078);	//eori.b #$78, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x87654359, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testWord()
	{
		setInstructionParamW(0x0a40, 0xaa78);	//eori.w #$aa78, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x8765e959, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testLong()
	{
		setInstructionParamL(0x0a80, 0x12345678);	//eori.l #$12345678, d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x95511559, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertTrue("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testMem()
	{
		setInstructionParamL(0x0a90, 0xc0c0cccc);	//eori.l #$c0c0ccc,(a0)
		SystemModel.CPU.setAddrRegister(0, 32);
		SystemModel.MEM.poke(32, 0x87654321, Size.Long);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x47a58fed, SystemModel.MEM.peek(32, Size.Long));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}
}
