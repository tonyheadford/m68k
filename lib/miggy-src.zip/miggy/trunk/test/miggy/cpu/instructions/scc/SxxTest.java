package miggy.cpu.instructions.scc;

import miggy.BasicSetup;
import miggy.SystemModel;
import miggy.api.cpu.CpuFlag;

// $Revision: 21 $
public class SxxTest extends BasicSetup
{
	public SxxTest(String test)
	{
		super(test);
	}

	public void testSet()
	{
		setInstruction(0x54c0);	//scc d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x876543ff, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}

	public void testNotSet()
	{
		setInstruction(0x55c0);	//scs d0
		SystemModel.CPU.setDataRegister(0, 0x87654321);

		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", 0x87654300, SystemModel.CPU.getDataRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}
}
