package miggy.cpu.operands;

import miggy.BasicSetup;
import miggy.SystemModel;
import miggy.api.cpu.CpuFlag;
import miggy.api.cpu.Size;

// $Revision: 21 $
public class PCDisplaceTest extends BasicSetup
{
	public PCDisplaceTest(String test)
	{
		super(test);
	}

	public void testInstruction()
	{
		SystemModel.MEM.poke(codebase + 0x00e4, 0x41faff1c, Size.Long);	//lea $-e4(pc),a0
		SystemModel.MEM.poke(codebase, 0x00c00000, Size.Long);
		SystemModel.CPU.setAddrRegister(0, 0x87654321);
		SystemModel.CPU.setPC(codebase + 0x00e4);
		SystemModel.CPU.setCCR((byte)0);

		int time = SystemModel.CPU.execute();

		assertEquals("Check result", codebase + 2, SystemModel.CPU.getAddrRegister(0));
		assertFalse("Check X", SystemModel.CPU.isSet(CpuFlag.X));
		assertFalse("Check N", SystemModel.CPU.isSet(CpuFlag.N));
		assertFalse("Check Z", SystemModel.CPU.isSet(CpuFlag.Z));
		assertFalse("Check V", SystemModel.CPU.isSet(CpuFlag.V));
		assertFalse("Check C", SystemModel.CPU.isSet(CpuFlag.C));
	}
}
