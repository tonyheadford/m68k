package miggy.utils;

import junit.framework.TestCase;

// $Revision: 16 $
public class TextUtilTest extends TestCase
{
	public TextUtilTest(String test)
	{
		super(test);
	}

	public void testDecodeRegList()
	{
		int list = 0x00c0;
		String s = TextUtil.decodeRegList(list, false);
		assertEquals("Two together", "d6/d7", s);

		list = 0x03e0;
		s = TextUtil.decodeRegList(list, false);
		assertEquals("Two groups", "d5-d7/a0/a1", s);

		list = 0xc3e7;
		s = TextUtil.decodeRegList(list, false);
		assertEquals("Multiple groups", "d0-d2/d5-d7/a0/a1/a6/a7", s);

		//now in reverse mode
		list = 0x00c0;
		s = TextUtil.decodeRegList(list, true);
		assertEquals("Reverse Two together", "a0/a1", s);

		list = 0x03e0;
		s = TextUtil.decodeRegList(list, true);
		assertEquals("Reverse Two groups", "d6/d7/a0-a2", s);

		list = 0xc3e7;
		s = TextUtil.decodeRegList(list, true);
		assertEquals("Reverse Multiple groups", "d0/d1/d6/d7/a0-a2/a5-a7", s);
	}
}
